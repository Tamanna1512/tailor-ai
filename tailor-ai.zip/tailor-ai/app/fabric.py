"""Image decoding and fabric texture extraction."""
import io
import math

import cv2
import numpy as np
from PIL import Image, ImageOps


def decode_image(data: bytes, max_side: int = 1280):
    """Decode uploaded bytes to a BGR numpy image (EXIF-rotated, downscaled)."""
    img = Image.open(io.BytesIO(data))
    img = ImageOps.exif_transpose(img).convert("RGB")
    img.thumbnail((max_side, max_side))
    return cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)


def parse_crop(text):
    """'x,y,w,h' (all 0-1 fractions of the image) -> tuple or None."""
    if not text:
        return None
    try:
        x, y, w, h = [float(v) for v in text.split(",")]
    except Exception:
        return None
    x, y = min(max(x, 0.0), 1.0), min(max(y, 0.0), 1.0)
    w, h = min(max(w, 0.0), 1.0 - x), min(max(h, 0.0), 1.0 - y)
    if w < 0.02 or h < 0.02:
        return None
    return x, y, w, h


def extract_texture(src_bgr, crop=None, size: int = 192):
    """Cut a square fabric sample out of `src_bgr`.

    crop: (x, y, w, h) as image fractions, or None for the central area.
    Returns (texture_bgr, dominant_hex).
    """
    h, w = src_bgr.shape[:2]
    if crop is None:
        x0, y0, x1, y1 = int(w * 0.30), int(h * 0.30), int(w * 0.70), int(h * 0.70)
    else:
        cx, cy, cw, ch = crop
        x0, y0 = int(cx * w), int(cy * h)
        x1, y1 = int((cx + cw) * w), int((cy + ch) * h)
    if x1 - x0 < 12 or y1 - y0 < 12:
        x0, y0, x1, y1 = int(w * 0.30), int(h * 0.30), int(w * 0.70), int(h * 0.70)
    region = src_bgr[y0:y1, x0:x1]

    # central square of the region
    rh, rw = region.shape[:2]
    s = min(rh, rw)
    oy, ox = (rh - s) // 2, (rw - s) // 2
    sq = region[oy:oy + s, ox:ox + s]
    tex = cv2.resize(sq, (size, size), interpolation=cv2.INTER_AREA)

    # Flatten lighting so folds / shadows in the photo do not become a "print".
    f = tex.astype(np.float32)
    mean = f.reshape(-1, 3).mean(axis=0)
    blur = cv2.GaussianBlur(f, (0, 0), size / 3.0)
    flat = f / np.maximum(blur, 1.0) * mean
    tex = np.clip(0.3 * f + 0.7 * flat, 0, 255).astype(np.uint8)

    b, g, r = [int(v) for v in mean]
    return tex, "#%02x%02x%02x" % (r, g, b)


def make_tiled(tex, out_h: int, out_w: int, tile_px: int):
    """Repeat the texture over the whole canvas. Mirrored tiling avoids visible seams."""
    tile_px = max(32, int(tile_px))
    tile = cv2.resize(tex, (tile_px, tile_px), interpolation=cv2.INTER_AREA)
    mirrored = np.vstack([
        np.hstack([tile, tile[:, ::-1]]),
        np.hstack([tile[::-1], tile[::-1, ::-1]]),
    ])
    ry = math.ceil(out_h / mirrored.shape[0])
    rx = math.ceil(out_w / mirrored.shape[1])
    big = np.tile(mirrored, (ry, rx, 1))
    return big[:out_h, :out_w].copy()
