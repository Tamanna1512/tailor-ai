"""Turn a free-text style description into a garment spec.

1. A built-in keyword parser (English + common Hinglish words) always works offline.
2. If ANTHROPIC_API_KEY is set, an LLM reads the text first (any language, e.g. Hindi / Marathi)
   and its answer overrides the keyword parser wherever it is confident.

Details the preview cannot draw (pockets, embroidery, lace ...) are collected as "extras"
and printed in the tailor instructions.
"""
import json
import os
import re

from .garments import (GARMENTS, OPTIONS, FIELDS, FIELD_LABELS, normalize_spec, option_label)

GARMENT_PATTERNS = [
    ("kurta", r"\bkurt[ah]?i?s?\b|\bkurti\b|\bkameez\b|\banarkali\b"),
    ("blouse", r"\bblouse\b|\bcholi\b|\bcrop top\b"),
    ("shirt", r"\bshirt\b|\bkameej\b"),
    ("dress", r"\bdress\b|\bgown\b|\bfrock\b|\bmaxi\b"),
    ("salwar", r"\bsalwar\b|\bsalwaar\b|\bshalwar\b|\bpants?\b|\btrousers?\b|\bpajama\b|\bpayjama\b|\bchuridar\b|\bpatiala\b|\bpalazzo\b|\bplazo\b|\bsharara\b|\bbottom\b"),
    ("lehenga", r"\blehenga\b|\blehnga\b|\bghagra\b|\bghaghra\b|\bskirt\b"),
]

# word -> settings applied only when the user did not state them explicitly
GARMENT_HINTS = [
    (r"\banarkali\b", {"garment": "kurta", "fit": "a_line", "length": "calf"}),
    (r"\bpatiala\b", {"garment": "salwar", "fit": "loose"}),
    (r"\bpalazzo\b|\bplazo\b|\bsharara\b", {"garment": "salwar", "fit": "a_line"}),
    (r"\bchuridar\b", {"garment": "salwar", "fit": "slim"}),
]

SLEEVE_PATTERNS = [
    ("sleeveless", r"sleeveless|sleeve less|without sleeves?|no sleeves?|bina baju|bina bahi"),
    ("three_quarter", r"3\s*/\s*4|3\s*quarter|three\s*quarter|elbow length|elbow sleeves?"),
    ("short", r"short sleeves?|half sleeves?|cap sleeves?|short hand|half hand|half baju"),
    ("full", r"full sleeves?|long sleeves?|full hand|full baju|wrist length"),
]
NECK_PATTERNS = [
    ("high", r"high neck|mandarin|chinese collar|stand collar|band collar|turtle ?neck|collar neck high"),
    ("collar", r"collar|polo|shirt neck"),
    ("v", r"\bv ?neck|v shape|deep v|\bv cut"),
    ("boat", r"boat|bateau"),
    ("square", r"square"),
    ("round", r"round|crew|\bu ?neck\b|u shape|keyhole"),
]
FIT_PATTERNS = [
    ("a_line", r"a ?line|flared?|umbrella|circular|flowy|anarkali|palazzo|plazo|sharara"),
    ("slim", r"slim|fitted|tight|skinny|churidar|body ?fit|snug"),
    ("loose", r"loose|baggy|oversized?|relaxed|patiala|comfortable"),
    ("regular", r"regular|straight fit|normal fit|straight cut"),
]
LENGTH_PATTERNS = [
    ("thigh", r"mid ?thigh|thigh|above (the )?knee|short kurta"),
    ("crop", r"crop|waist length|above (the )?waist|short length|\bshort\b"),
    ("calf", r"calf|midi|below (the )?knee|mid length|3/4 length"),
    ("knee", r"knee"),
    ("hip", r"hip|tunic"),
    ("ankle", r"ankle|full length|floor|maxi|gown length|long length"),
]

EXTRA_KEYWORDS = {
    "pocket": "pockets", "slit": "side slits", "embroider": "embroidery", "lace": "lace",
    "piping": "piping", "zip": "zip", "button": "buttons", "border": "border / patti",
    "tassel": "tassels / latkan", "pleat": "pleats", "frill": "frills", "belt": "belt",
    "dupatta": "dupatta", "lining": "lining", "padding": "padding", "back neck": "back neck design",
    "cut work": "cut work", "mirror work": "mirror work", "sequin": "sequins", "dori": "dori / ties",
    "gher": "extra flare (gher)", "sleeve design": "sleeve design",
}


def _norm(text: str) -> str:
    t = " " + text.lower().replace("¾", "3/4").replace("-", " ").replace("_", " ") + " "
    return re.sub(r"\s+", " ", t)


def _take(patterns, t):
    """First pattern (in priority order) that matches. Returns (value, text_without_match)."""
    for value, rx in patterns:
        m = re.search(rx, t)
        if m:
            return value, t[:m.start()] + " " + t[m.end():]
    return None, t


def rule_parse(text: str) -> dict:
    t = _norm(text)
    spec = {}

    best = None
    for g, rx in GARMENT_PATTERNS:
        m = re.search(rx, t)
        if m and (best is None or m.start() < best[0]):
            best = (m.start(), g)
    if best:
        spec["garment"] = best[1]

    sleeve, t = _take(SLEEVE_PATTERNS, t)
    if sleeve:
        spec["sleeve"] = sleeve
    neck, t = _take(NECK_PATTERNS, t)
    if neck:
        spec["neckline"] = neck

    hints = {}
    for rx, vals in GARMENT_HINTS:
        if re.search(rx, t):
            hints.update(vals)
    fit, t = _take(FIT_PATTERNS, t)
    if fit:
        spec["fit"] = fit
    length, t = _take(LENGTH_PATTERNS, t)
    if length:
        spec["length"] = length

    # "long" on its own
    if "length" not in spec and re.search(r"\blong\b", t):
        g = spec.get("garment") or hints.get("garment") or "kurta"
        spec["length"] = "ankle" if g in ("salwar", "lehenga", "dress") else "calf"

    for k, v in hints.items():
        spec.setdefault(k, v)

    low = text.lower()
    extras = []
    for key, label in EXTRA_KEYWORDS.items():
        if key in low and label not in extras:
            extras.append(label)
    spec["extras"] = extras
    return spec


SYSTEM_PROMPT = (
    "You convert a tailoring customer's description of a garment (any language, e.g. English, "
    "Hindi, Marathi, Hinglish) into JSON. Reply with ONLY a JSON object with these keys:\n"
    '  "garment": one of ' + json.dumps(list(GARMENTS)) + " or null\n"
    '  "neckline": one of ' + json.dumps([v for v, _ in OPTIONS["neckline"]]) + " or null\n"
    '  "sleeve": one of ' + json.dumps([v for v, _ in OPTIONS["sleeve"]]) + " or null\n"
    '  "length": one of ' + json.dumps([v for v, _ in OPTIONS["length"]]) + " or null\n"
    '  "fit": one of ' + json.dumps([v for v, _ in OPTIONS["fit"]]) + " or null\n"
    '  "extras": list of short English phrases for details that cannot be drawn in a simple '
    "preview (pockets, embroidery, lace, slits, buttons, border, back neck design ...)\n"
    "Use null when the customer did not say. Do not invent details."
)


def llm_parse(text: str):
    """Return a partial spec from Claude, or None when no key / any error."""
    if not os.getenv("ANTHROPIC_API_KEY"):
        return None
    try:
        import anthropic

        client = anthropic.Anthropic()
        msg = client.messages.create(
            model=os.getenv("TAILOR_LLM_MODEL", "claude-sonnet-5-5"),
            max_tokens=400,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": text}],
        )
        raw = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")
        m = re.search(r"\{.*\}", raw, re.S)
        data = json.loads(m.group(0)) if m else None
        if not isinstance(data, dict):
            return None
        out = {}
        if data.get("garment") in GARMENTS:
            out["garment"] = data["garment"]
        for f in FIELDS:
            if data.get(f) in [v for v, _ in OPTIONS[f]]:
                out[f] = data[f]
        if isinstance(data.get("extras"), list):
            out["extras"] = [str(x)[:60] for x in data["extras"]][:12]
        return out
    except Exception:
        return None


def parse_description(text: str) -> dict:
    """Free text -> normalized spec (plus 'source' and 'warnings')."""
    warnings = []
    rules = rule_parse(text)
    spec = dict(rules)
    source = "rules"
    llm = llm_parse(text)
    if llm:
        source = "llm"
        for k, v in llm.items():
            if k == "extras":
                spec["extras"] = sorted(set(spec.get("extras", [])) | set(v))
            else:
                spec[k] = v
    if "garment" not in spec:
        warnings.append("Could not tell which garment you want, so a kurta is shown. "
                        "Mention kurta, blouse, shirt, salwar, lehenga or dress.")
    # When the garment was guessed, start from its defaults for anything unspecified.
    out = normalize_spec(spec)
    out["source"] = source
    out["warnings"] = warnings
    return out


def build_instructions(spec, description, measurements, color_hex):
    """Plain-text sheet for the tailor."""
    lines = [f"Garment: {GARMENTS[spec['garment']]['label']}"]
    for f in FIELDS:
        if spec.get(f):
            lines.append(f"{FIELD_LABELS[f]}: {option_label(f, spec[f])}")
    if color_hex:
        lines.append(f"Fabric colour (approx.): {color_hex}")
    if description and description.strip():
        lines.append(f"Customer's request: \"{description.strip()}\"")
    if spec.get("extras"):
        lines.append("Extra details (NOT shown in preview): " + ", ".join(spec["extras"]))
    if measurements:
        lines.append("")
        lines.append("Estimated measurements from photo (verify with a tape before cutting):")
        for k, v in measurements.items():
            if k.endswith("_cm"):
                lines.append(f"  - {k[:-3].replace('_', ' ').title()}: {v} cm")
    lines.append("")
    lines.append("Note: the preview is an AI illustration. Final fit and drape depend on the tailor.")
    return "\n".join(lines)
