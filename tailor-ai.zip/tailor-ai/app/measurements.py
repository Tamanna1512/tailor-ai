"""Rough body measurements from ONE photo.

Needs: a detected pose, a nearly full-body photo and the person's real height.
Everything here is an estimate (usually within a few cm at best) - a tailor must still
take final measurements with a tape.
"""
import math

import numpy as np


def _ellipse_circumference(width, depth):
    a, b = width / 2.0, depth / 2.0
    return math.pi * (3 * (a + b) - math.sqrt((3 * a + b) * (a + 3 * b)))


def estimate(kp, height_cm, img_shape):
    """Return a dict of measurements in cm, or None if the photo is not suitable."""
    if not height_cm or not (80 <= height_cm <= 230):
        return None
    h, w = img_shape[:2]
    nose = kp["nose"]
    ankle = (kp["an_l"] + kp["an_r"]) / 2
    if ankle[1] > h * 1.02 or ankle[1] - nose[1] < 0.35 * h:
        return None  # full body not visible
    body_px = (ankle[1] - nose[1]) * 1.12  # nose->ankle is ~89% of total height
    scale = height_cm / body_px

    S = (kp["sh_l"] + kp["sh_r"]) / 2
    H = (kp["hip_l"] + kp["hip_r"]) / 2
    sh_px = abs(kp["sh_r"][0] - kp["sh_l"][0])
    hip_px = abs(kp["hip_r"][0] - kp["hip_l"][0])

    shoulder = sh_px * scale * 1.08
    chest_w = sh_px * scale * 0.75
    waist_w = chest_w * 0.88
    hip_w = hip_px * scale * 1.45

    def d(a, b):
        return float(np.linalg.norm(np.asarray(a) - np.asarray(b)))

    arm = d(kp["sh_l"], kp["el_l"]) + d(kp["el_l"], kp["wr_l"])
    arm2 = d(kp["sh_r"], kp["el_r"]) + d(kp["el_r"], kp["wr_r"])

    out = {
        "height_cm": round(height_cm),
        "shoulder_width_cm": round(shoulder),
        "chest_cm": round(_ellipse_circumference(chest_w, chest_w * 0.78)),
        "waist_cm": round(_ellipse_circumference(waist_w, waist_w * 0.80)),
        "hip_cm": round(_ellipse_circumference(hip_w, hip_w * 0.75)),
        "shoulder_to_waist_cm": round((H[1] - S[1]) * 0.78 * scale),
        "shoulder_to_hip_cm": round((H[1] - S[1]) * scale),
        "shoulder_to_knee_cm": round((((kp["kn_l"][1] + kp["kn_r"][1]) / 2) - S[1]) * scale),
        "shoulder_to_ankle_cm": round((ankle[1] - S[1]) * scale),
        "arm_length_cm": round(max(arm, arm2) * scale),
        "hip_to_ankle_cm": round((ankle[1] - H[1]) * scale),
        "confidence": "low",
    }
    return out
