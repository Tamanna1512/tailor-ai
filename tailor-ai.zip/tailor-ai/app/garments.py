"""Garment catalog, geometry and rendering (classic computer vision).

A garment is described by a small "spec" dict:
    {garment, neckline, sleeve, length, fit, extras}
The renderer builds a mask for that garment from the body keypoints, fills it with the
customer's fabric texture, adds shading + stitch lines and blends it onto the photo.
"""
import math

import cv2
import numpy as np

from .fabric import make_tiled

# --------------------------------------------------------------------------- catalog

GARMENTS = {
    "kurta": {
        "label": "Kurta / Kurti",
        "applies": ["neckline", "sleeve", "length", "fit"],
        "defaults": {"neckline": "round", "sleeve": "three_quarter", "length": "knee", "fit": "regular"},
    },
    "blouse": {
        "label": "Blouse / Choli",
        "applies": ["neckline", "sleeve", "length", "fit"],
        "defaults": {"neckline": "round", "sleeve": "short", "length": "crop", "fit": "slim"},
    },
    "shirt": {
        "label": "Shirt",
        "applies": ["neckline", "sleeve", "length", "fit"],
        "defaults": {"neckline": "collar", "sleeve": "full", "length": "hip", "fit": "regular"},
    },
    "dress": {
        "label": "Dress / Gown",
        "applies": ["neckline", "sleeve", "length", "fit"],
        "defaults": {"neckline": "round", "sleeve": "short", "length": "calf", "fit": "a_line"},
    },
    "salwar": {
        "label": "Salwar / Pants",
        "applies": ["length", "fit"],
        "defaults": {"length": "ankle", "fit": "regular"},
    },
    "lehenga": {
        "label": "Lehenga / Skirt",
        "applies": ["length", "fit"],
        "defaults": {"length": "ankle", "fit": "a_line"},
    },
}

OPTIONS = {
    "neckline": [("round", "Round"), ("v", "V-neck"), ("boat", "Boat"), ("square", "Square"),
                 ("collar", "Collar"), ("high", "High / Mandarin")],
    "sleeve": [("sleeveless", "Sleeveless"), ("short", "Short"), ("three_quarter", "3/4 sleeve"), ("full", "Full sleeve")],
    "length": [("crop", "Crop / Short"), ("hip", "Hip"), ("thigh", "Mid-thigh"), ("knee", "Knee"),
               ("calf", "Calf / Midi"), ("ankle", "Ankle / Full")],
    "fit": [("slim", "Slim / Fitted"), ("regular", "Regular"), ("loose", "Loose"), ("a_line", "A-line / Flared")],
}
FIELDS = ["neckline", "sleeve", "length", "fit"]
FIELD_LABELS = {"neckline": "Neckline", "sleeve": "Sleeves", "length": "Length", "fit": "Fit"}


def option_label(field, value):
    for v, lab in OPTIONS.get(field, []):
        if v == value:
            return lab
    return str(value)


def catalog():
    return {
        "garments": [{"id": k, **v} for k, v in GARMENTS.items()],
        "options": {k: [{"value": v, "label": l} for v, l in lst] for k, lst in OPTIONS.items()},
    }


def normalize_spec(spec: dict) -> dict:
    g = spec.get("garment")
    if g not in GARMENTS:
        g = "kurta"
    info = GARMENTS[g]
    out = {"garment": g}
    for f in FIELDS:
        if f not in info["applies"]:
            out[f] = None
            continue
        valid = [v for v, _ in OPTIONS[f]]
        val = spec.get(f)
        out[f] = val if val in valid else info["defaults"][f]
    out["extras"] = list(spec.get("extras") or [])
    return out


def describe_spec(spec: dict):
    rows = [{"label": "Garment", "value": GARMENTS[spec["garment"]]["label"]}]
    for f in FIELDS:
        if spec.get(f):
            rows.append({"label": FIELD_LABELS[f], "value": option_label(f, spec[f])})
    return rows


# --------------------------------------------------------------------------- geometry

BODY = {"slim": 0.94, "regular": 1.06, "loose": 1.22, "a_line": 1.04}
HEM = {"slim": 0.95, "regular": 1.08, "loose": 1.28, "a_line": 1.75}
SLEEVE_F = {"slim": 0.9, "regular": 1.0, "loose": 1.3, "a_line": 1.05}
LEG_F = {  # (thigh, knee, ankle) multipliers
    "slim": (0.9, 0.75, 0.6),
    "regular": (1.0, 0.95, 0.85),
    "loose": (1.1, 1.1, 1.2),
    "a_line": (1.0, 1.2, 1.7),
}
SKIRT_FLARE = {"slim": 1.3, "regular": 2.0, "loose": 2.6, "a_line": 3.0}


def _context(kp):
    S = (kp["sh_l"] + kp["sh_r"]) / 2
    H = (kp["hip_l"] + kp["hip_r"]) / 2
    A = (kp["an_l"] + kp["an_r"]) / 2
    K = (kp["kn_l"] + kp["kn_r"]) / 2
    sw = max(abs(kp["sh_r"][0] - kp["sh_l"][0]), 1.0)
    torso = max(H[1] - S[1], sw * 0.9)
    hip_w = max(abs(kp["hip_r"][0] - kp["hip_l"][0]), sw * 0.35)
    leg = max(A[1] - H[1], torso * 1.2)
    Ky = float(np.clip(K[1], H[1] + 0.35 * leg, H[1] + 0.65 * leg))
    return {"S": S, "H": H, "sw": sw, "torso": torso, "hip_w": hip_w, "leg": leg, "Ky": Ky,
            "Ay": H[1] + leg}


def _hem_y(length, c, lower):
    S, H, T, L, Ky, Ay = c["S"][1], c["H"][1], c["torso"], c["leg"], c["Ky"], c["Ay"]
    if lower:
        table = {"crop": H + 0.35 * L, "hip": H + 0.35 * L, "thigh": H + 0.5 * L, "knee": Ky,
                 "calf": Ky + 0.5 * (Ay - Ky), "ankle": Ay - 0.03 * L}
    else:
        table = {"crop": S + 0.78 * T, "hip": H + 0.12 * T, "thigh": H + 0.5 * L * 0.9, "knee": Ky,
                 "calf": Ky + 0.5 * (Ay - Ky), "ankle": Ay - 0.04 * L}
    return float(table.get(length, Ky))


def _neckline(neck, cx, ytop, sw, T):
    """Return (points left->right along the neck opening, extra pieces to add to the mask)."""
    nw = sw * 0.17
    extras = []
    if neck == "v":
        pts = [(cx - nw, ytop), (cx, ytop + sw * 0.38), (cx + nw, ytop)]
    elif neck == "boat":
        nw = sw * 0.37
        t = np.linspace(math.pi, 0, 14)
        pts = [(cx + nw * math.cos(a), ytop + sw * 0.055 * math.sin(a)) for a in t]
    elif neck == "square":
        nw = sw * 0.22
        d = sw * 0.22
        pts = [(cx - nw, ytop), (cx - nw, ytop + d), (cx + nw, ytop + d), (cx + nw, ytop)]
    elif neck == "collar":
        d = sw * 0.16
        pts = [(cx - nw, ytop), (cx, ytop + d), (cx + nw, ytop)]
        # two collar flaps standing up around the neck
        extras.append([(cx - nw * 1.05, ytop - 0.045 * T), (cx - nw * 0.1, ytop + d * 1.05),
                       (cx - nw * 1.9, ytop + d * 0.45)])
        extras.append([(cx + nw * 1.05, ytop - 0.045 * T), (cx + nw * 0.1, ytop + d * 1.05),
                       (cx + nw * 1.9, ytop + d * 0.45)])
    elif neck == "high":
        nw = sw * 0.16
        pts = [(cx - nw, ytop), (cx - nw * 0.4, ytop + sw * 0.03), (cx + nw * 0.4, ytop + sw * 0.03), (cx + nw, ytop)]
        extras.append([(cx - nw, ytop), (cx - nw * 0.9, ytop - 0.07 * T), (cx + nw * 0.9, ytop - 0.07 * T), (cx + nw, ytop)])
    else:  # round
        t = np.linspace(math.pi, 0, 16)
        pts = [(cx + nw * math.cos(a), ytop + sw * 0.20 * math.sin(a)) for a in t]
    return pts, extras


def _tube(mask, path, radii, stop_len=None, step=2.0):
    """Draw a tapered tube along a poly-line `path` with radius interpolated by `radii`."""
    path = [np.asarray(p, dtype=float) for p in path]
    seg = [np.linalg.norm(path[i + 1] - path[i]) for i in range(len(path) - 1)]
    total = sum(seg)
    if total < 1:
        return
    stop = total if stop_len is None else min(stop_len, total)
    marks = np.cumsum([0] + seg)
    n = max(int(stop / step), 2)
    for d in np.linspace(0, stop, n):
        i = min(int(np.searchsorted(marks, d, side="right") - 1), len(seg) - 1)
        f = (d - marks[i]) / max(seg[i], 1e-6)
        p = path[i] * (1 - f) + path[i + 1] * f
        r = radii[i] * (1 - f) + radii[i + 1] * f
        cv2.circle(mask, (int(round(p[0])), int(round(p[1]))), max(int(round(r)), 1), 255, -1, cv2.LINE_AA)


def _poly(mask, pts):
    cv2.fillPoly(mask, [np.round(np.array(pts)).astype(np.int32)], 255, cv2.LINE_AA)


def _upper_mask(mask, kp, spec, c):
    g, fit, neck, sleeve = spec["garment"], spec["fit"], spec["neckline"], spec["sleeve"]
    S, H, sw, T = c["S"], c["H"], c["sw"], c["torso"]
    body, hemf = BODY[fit], HEM[fit]
    if g == "blouse":
        hemf = min(hemf, 1.0)
    hy = max(_hem_y(spec["length"], c, False), S[1] + 0.5 * T)

    y_tip = S[1] - 0.015 * T
    y_chest, y_waist, y_hip = S[1] + 0.32 * T, S[1] + 0.72 * T, H[1]
    pad = 0.06 * sw if sleeve != "sleeveless" else -0.14 * sw
    half_tip = sw * 0.5 + pad
    half_chest = sw * 0.5 * 1.04 * body
    half_waist = sw * 0.5 * (0.80 if g == "blouse" else 0.90) * body
    half_hip = max(c["hip_w"] * 0.5 * 1.4, sw * 0.5 * 0.95) * body
    hem_hw = half_hip * hemf

    ys = [y_tip, y_chest, y_waist, y_hip, max(hy, y_hip + 1)]
    ws = [half_tip, half_chest, half_waist, half_hip, hem_hw]

    def cx(y):
        t = np.clip((y - S[1]) / T, 0, 1.3)
        return S[0] + (H[0] - S[0]) * t

    yy = np.linspace(y_tip, hy, 30)
    half = np.interp(yy, ys, ws)
    cxs = np.array([cx(v) for v in yy])
    left = list(zip(cxs - half, yy))
    right = list(zip(cxs + half, yy))

    u = np.linspace(0, 1, 14)
    xl, xr = left[-1][0], right[-1][0]
    hem = [(xl + (xr - xl) * a, hy + 0.012 * T * math.sin(math.pi * a)) for a in u]

    ytop = S[1] - 0.05 * T
    neck_pts, extras = _neckline(neck, float(cx(ytop)), ytop, sw, T)
    poly = left + hem + right[::-1] + neck_pts[::-1]
    _poly(mask, poly)
    for e in extras:
        _poly(mask, e)

    if sleeve != "sleeveless":
        sf = SLEEVE_F[fit]
        for side in ("l", "r"):
            sh, el, wr = kp["sh_" + side], kp["el_" + side], kp["wr_" + side]
            d1 = float(np.linalg.norm(el - sh))
            d2 = float(np.linalg.norm(wr - el))
            stop = {"short": 0.5 * d1, "three_quarter": d1 + 0.55 * d2, "full": d1 + 0.97 * d2}[sleeve]
            radii = [0.16 * sw * sf, 0.12 * sw * sf, 0.10 * sw * sf]
            if sleeve == "short":
                radii[1] = radii[0] * 0.92
            start = sh + (np.array([S[0], sh[1]]) - sh) * 0.12  # begin slightly inside the shoulder
            _tube(mask, [start, el, wr], radii, stop_len=stop + 0.12 * d1)
    return {"flare": fit in ("a_line", "loose") or g == "dress"}


def _lower_mask(mask, kp, spec, c):
    g, fit = spec["garment"], spec["fit"]
    S, H, T, L, hip_w, sw = c["S"], c["H"], c["torso"], c["leg"], c["hip_w"], c["sw"]
    hy = _hem_y(spec["length"], c, True)

    if g == "salwar":
        mt, mk, ma = LEG_F[fit]
        r_hip, r_kn, r_an = hip_w * 0.42 * mt, hip_w * 0.34 * mk, hip_w * 0.26 * ma
        for side in ("l", "r"):
            hp, kn, an = kp["hip_" + side], kp["kn_" + side], kp["an_" + side]
            # keep the legs vertical-ish and make sure the path reaches the hem
            end = np.array([an[0], max(an[1], hy)])
            path = [hp, np.array([kn[0], c["Ky"]]), end]
            total_to_hem = float(np.linalg.norm(np.array([kn[0], c["Ky"]]) - hp)) + max(
                0.0, hy - c["Ky"]) * 1.0
            _tube(mask, path, [r_hip, r_kn, r_an], stop_len=total_to_hem)
        waist_y = H[1] - 0.25 * T
        ww = max(sw * 0.5 * 0.8, hip_w * 0.5 * 1.2)
        crotch = H[1] + 0.28 * L
        outer = r_hip * 0.9
        _poly(mask, [(H[0] - ww, waist_y), (H[0] + ww, waist_y),
                     (kp["hip_r"][0] + outer, crotch), (kp["hip_l"][0] - outer, crotch)])
        return {"flare": fit in ("a_line", "loose")}

    # lehenga / skirt
    waist_y = H[1] - 0.15 * T
    base = max(hip_w * 0.6, sw * 0.42)
    waist_hw = base * 0.95
    hem_hw = base * SKIRT_FLARE[fit]
    hy = max(hy, waist_y + 0.3 * L)
    n = 30
    left, right = [], []
    for i in range(n + 1):
        t = i / n
        y = waist_y + (hy - waist_y) * t
        hw = waist_hw + (hem_hw - waist_hw) * (t ** 0.85)
        left.append((H[0] - hw, y))
        right.append((H[0] + hw, y))
    hem = []
    xl, xr = left[-1][0], right[-1][0]
    for a in np.linspace(0, 1, 40):
        hem.append((xl + (xr - xl) * a, hy + 0.012 * c["leg"] * math.sin(5 * math.pi * a) + 0.01 * c["leg"] * math.sin(math.pi * a)))
    _poly(mask, left + hem + right[::-1])
    return {"flare": True}


def build_mask(shape, kp, spec):
    h, w = shape[:2]
    mask = np.zeros((h, w), np.uint8)
    c = _context(kp)
    if spec["garment"] in ("salwar", "lehenga"):
        meta = _lower_mask(mask, kp, spec, c)
        bottom = _hem_y(spec["length"], c, True)
    else:
        meta = _upper_mask(mask, kp, spec, c)
        bottom = _hem_y(spec["length"], c, False)
    meta["bottom_y"] = bottom
    return mask, meta


# --------------------------------------------------------------------------- rendering


def _shade(mask, meta, w):
    """Cheap 3D look: darker near the edges + soft vertical folds for flared garments."""
    dist = cv2.distanceTransform(mask, cv2.DIST_L2, 5)
    ref = max(8.0, 0.075 * w)
    d = np.clip(dist / ref, 0, 1)
    shade = 0.66 + 0.34 * np.power(d, 0.55)
    if meta.get("flare"):
        h = mask.shape[0]
        xs = np.arange(w, dtype=np.float32)[None, :]
        ys = np.arange(h, dtype=np.float32)[:, None]
        period = max(18.0, 0.05 * w)
        folds = np.sin(2 * math.pi * xs / period + 2.2 * np.sin(ys / (0.18 * h)))
        shade = shade * (1.0 + 0.07 * folds)
    return shade.astype(np.float32)


def render(person_bgr, texture_bgr, kp, spec, fabric_scale: float = 1.0):
    """Return (preview_bgr, warnings)."""
    h, w = person_bgr.shape[:2]
    warnings = []
    mask, meta = build_mask(person_bgr.shape, kp, spec)

    if meta["bottom_y"] > h * 1.03:
        warnings.append("The garment is longer than the photo. Use a full-length photo to see the complete outfit.")
    if mask.sum() == 0:
        warnings.append("Could not place the garment on this photo.")
        return person_bgr.copy(), warnings

    tile_px = max(48, int(w * 0.18 * max(0.3, min(fabric_scale, 3.0))))
    canvas = make_tiled(texture_bgr, h, w, tile_px).astype(np.float32)
    garment = canvas * _shade(mask, meta, w)[..., None]

    # stitch lines: darker seam at the edge + dashed topstitch just inside it
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    inner = cv2.erode(mask, k)
    edge = (mask > 0) & (inner == 0)
    garment[edge] *= 0.80
    lum = float(texture_bgr.mean())
    stitch_color = (40, 40, 40) if lum > 120 else (225, 225, 225)
    k2 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (13, 13))
    contours, _ = cv2.findContours(cv2.erode(mask, k2), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    garment8 = np.clip(garment, 0, 255).astype(np.uint8)
    for cnt in contours:
        pts = cnt[:, 0, :]
        n = len(pts)
        for i in range(0, n, 12):
            cv2.line(garment8, tuple(int(v) for v in pts[i]), tuple(int(v) for v in pts[min(i + 6, n - 1)]),
                     stitch_color, 1, cv2.LINE_AA)

    # soft drop shadow on the person, then blend the garment on top
    M = np.float32([[1, 0, 3], [0, 1, 6]])
    shadow = cv2.GaussianBlur(cv2.warpAffine(mask, M, (w, h)), (0, 0), 6).astype(np.float32) / 255.0
    person = person_bgr.astype(np.float32) * (1 - 0.25 * shadow[..., None])
    alpha = cv2.GaussianBlur(mask, (5, 5), 0).astype(np.float32)[..., None] / 255.0
    out = person * (1 - alpha) + garment8.astype(np.float32) * alpha
    return np.clip(out, 0, 255).astype(np.uint8), warnings
