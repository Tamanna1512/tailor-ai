"""StitchView - FastAPI backend.

Run:  uvicorn app.main:app --host 0.0.0.0 --port 8000
"""
import csv
import hmac
import io
import json
import logging
import os
import re
import time
import uuid
from collections import defaultdict, deque
from datetime import date
from pathlib import Path
from typing import Optional

import cv2
from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE_DIR = Path(__file__).resolve().parent.parent
try:  # optional .env support
    from dotenv import load_dotenv

    load_dotenv(BASE_DIR / ".env")
except Exception:
    pass

from . import db, fabric, garments, measurements, pose, spec_parser  # noqa: E402

log = logging.getLogger("stitchview")
logging.basicConfig(level=os.getenv("TAILOR_LOG_LEVEL", "INFO"),
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")

DATA_DIR = Path(os.getenv("TAILOR_DATA_DIR", BASE_DIR / "data"))
OUT_DIR = DATA_DIR / "outputs"
UP_DIR = DATA_DIR / "uploads"
for d in (OUT_DIR, UP_DIR):
    d.mkdir(parents=True, exist_ok=True)
db.init(DATA_DIR)

ADMIN_KEY = os.getenv("TAILOR_ADMIN_KEY", "")
MAX_BYTES = 15 * 1024 * 1024
PREVIEW_TTL_HOURS = float(os.getenv("TAILOR_PREVIEW_TTL_HOURS", "24"))
TRUST_PROXY = os.getenv("TAILOR_TRUST_PROXY", "") == "1"
ID_RE = re.compile(r"^[0-9a-f]{32}$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def shop_info() -> dict:
    return {
        "name": os.getenv("SHOP_NAME", "StitchView"),
        "tagline": os.getenv("SHOP_TAGLINE", "See your cloth stitched before it is cut"),
        "phone": os.getenv("SHOP_PHONE", ""),
        "whatsapp": re.sub(r"\D", "", os.getenv("SHOP_WHATSAPP", os.getenv("SHOP_PHONE", ""))),
        "address": os.getenv("SHOP_ADDRESS", ""),
        "logo": os.getenv("SHOP_LOGO", ""),
        "country_code": re.sub(r"\D", "", os.getenv("SHOP_COUNTRY_CODE", "91")),
        "currency": os.getenv("SHOP_CURRENCY", "₹"),
    }


app = FastAPI(title="StitchView - AI tailoring preview", docs_url="/docs" if os.getenv("TAILOR_DOCS", "1") == "1" else None,
              redoc_url=None)


# --------------------------------------------------------------------------- security helpers


@app.middleware("http")
async def security_headers(request: Request, call_next):
    resp = await call_next(request)
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    resp.headers.setdefault("Permissions-Policy", "camera=(self), microphone=(self), geolocation=()")
    path = request.url.path
    if path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    elif path.startswith("/files/"):
        resp.headers["Cache-Control"] = "private, max-age=3600"
    return resp


_hits = defaultdict(deque)


def client_ip(request: Request) -> str:
    if TRUST_PROXY:
        fwd = request.headers.get("x-forwarded-for", "")
        if fwd:
            return fwd.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def rate_limit(name: str, limit: int, per_seconds: int = 60):
    """FastAPI dependency: at most `limit` calls per `per_seconds` for each client address."""

    def dep(request: Request):
        now = time.time()
        q = _hits[(name, client_ip(request))]
        while q and q[0] < now - per_seconds:
            q.popleft()
        if len(q) >= limit:
            raise HTTPException(429, "Too many requests. Please wait a minute and try again.")
        q.append(now)

    return dep


def admin_auth(x_admin_key: Optional[str] = Header(None)):
    if ADMIN_KEY and not hmac.compare_digest((x_admin_key or "").encode(), ADMIN_KEY.encode()):
        raise HTTPException(401, "Admin key required.")


# --------------------------------------------------------------------------- helpers


def _read(upload: UploadFile) -> bytes:
    data = upload.file.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise HTTPException(413, "Image too large (max 15 MB).")
    return data


def cleanup_old_previews():
    """Delete preview photos that were never attached to an order (privacy)."""
    cutoff = time.time() - PREVIEW_TTL_HOURS * 3600
    keep = db.preview_ids_in_orders()
    for meta_file in OUT_DIR.glob("*.json"):
        pid = meta_file.stem
        if pid in keep or meta_file.stat().st_mtime > cutoff:
            continue
        _delete_preview_files(pid)


def _delete_preview_files(pid: str):
    if not ID_RE.match(pid):
        return
    for p in list(OUT_DIR.glob(pid + ".*")) + list(UP_DIR.glob(pid + "_*")):
        try:
            p.unlink()
        except OSError:
            pass


def _valid_date(text: str) -> bool:
    try:
        date.fromisoformat(text)
    except ValueError:
        return False
    return bool(DATE_RE.match(text))


def _url(kind, name):
    return f"/files/{kind}/{name}"


def _images(pid):
    return {
        "preview_url": _url("outputs", f"{pid}.jpg"),
        "original_url": _url("uploads", f"{pid}_person.jpg"),
        "swatch_url": _url("uploads", f"{pid}_fabric.jpg"),
    }


# --------------------------------------------------------------------------- public API


@app.get("/healthz", include_in_schema=False)
def healthz():
    return {"ok": True}


@app.get("/api/config")
def api_config():
    return {"shop": shop_info(), "admin_required": bool(ADMIN_KEY), "admin_protected": bool(ADMIN_KEY),
            "statuses": db.STATUSES}


@app.get("/api/catalog")
def api_catalog():
    cat = garments.catalog()
    cat["pose_engine"] = pose.engine()
    cat["llm_enabled"] = bool(os.getenv("ANTHROPIC_API_KEY"))
    cat["statuses"] = db.STATUSES
    return cat


@app.post("/api/preview", dependencies=[Depends(rate_limit("preview", 30))])
def api_preview(
    person: UploadFile = File(...),
    fabric_file: Optional[UploadFile] = File(None, alias="fabric"),
    fabric_crop: str = Form(""),
    mode: str = Form("catalog"),
    garment: str = Form("kurta"),
    neckline: str = Form(""),
    sleeve: str = Form(""),
    length: str = Form(""),
    fit: str = Form(""),
    description: str = Form(""),
    height_cm: Optional[float] = Form(None),
    fabric_scale: float = Form(1.0),
):
    cleanup_old_previews()

    try:
        person_img = fabric.decode_image(_read(person))
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(400, "Could not read the person photo. Please use a JPG or PNG image.")

    # --- fabric source: separate photo, or the same photo (cloth held / draped on the body)
    src = person_img
    if fabric_file is not None and fabric_file.filename:
        try:
            src = fabric.decode_image(_read(fabric_file))
        except HTTPException:
            raise
        except Exception:
            raise HTTPException(400, "Could not read the fabric photo.")
    texture, color_hex = fabric.extract_texture(src, fabric.parse_crop(fabric_crop))

    # --- what to stitch
    warnings = []
    if mode == "custom":
        if not description.strip():
            raise HTTPException(400, "Please describe the style you want.")
        spec = spec_parser.parse_description(description[:1000])
        warnings += spec.pop("warnings", [])
        spec_source = spec.pop("source", "rules")
    else:
        spec = garments.normalize_spec({"garment": garment, "neckline": neckline, "sleeve": sleeve,
                                        "length": length, "fit": fit})
        spec_source = "catalog"
        description = ""

    # --- body + render
    kp, detected = pose.detect_landmarks(person_img)
    if not detected:
        # Customers get a plain message; the technical reason goes to the server log for the shop owner.
        if not pose.mediapipe_available():
            log.warning("Body detection is not installed (pip install mediapipe); using a standard position.")
        elif pose.last_error():
            log.warning("Body-detection model could not be loaded: %s (see README, 'Pose model')", pose.last_error())
        warnings.append("We could not find your body in this photo, so a standard standing position was used "
                        "and the fit is approximate. For a better result, stand straight, face the camera "
                        "and keep your full body in the photo.")
    preview, render_warn = garments.render(person_img, texture, kp, spec, fabric_scale)
    warnings += render_warn

    meas = measurements.estimate(kp, height_cm, person_img.shape) if (detected and height_cm) else None
    if height_cm and not meas:
        warnings.append("Measurements need a detected body, a full-length photo and your real height (80-230 cm).")

    instructions = spec_parser.build_instructions(spec, description, meas, color_hex)

    pid = uuid.uuid4().hex
    cv2.imwrite(str(OUT_DIR / f"{pid}.jpg"), preview, [cv2.IMWRITE_JPEG_QUALITY, 90])
    cv2.imwrite(str(UP_DIR / f"{pid}_person.jpg"), person_img, [cv2.IMWRITE_JPEG_QUALITY, 88])
    cv2.imwrite(str(UP_DIR / f"{pid}_fabric.jpg"), texture, [cv2.IMWRITE_JPEG_QUALITY, 90])

    meta = {"id": pid, "spec": spec, "description": description, "instructions": instructions,
            "measurements": meas, "color": color_hex, "pose_detected": detected}
    (OUT_DIR / f"{pid}.json").write_text(json.dumps(meta))

    return {
        "id": pid,
        **_images(pid),
        "spec": spec,
        "spec_rows": garments.describe_spec(spec),
        "spec_source": spec_source,
        "extras": spec.get("extras", []),
        "instructions": instructions,
        "measurements": meas,
        "color": color_hex,
        "pose_detected": detected,
        "warnings": warnings,
    }


class OrderIn(BaseModel):
    preview_id: str
    customer_name: str
    phone: str
    consent: bool = False
    notes: str = ""
    due_date: str = ""  # date the customer needs it by, YYYY-MM-DD (optional)


@app.post("/api/orders", dependencies=[Depends(rate_limit("order", 10))])
def api_create_order(body: OrderIn):
    if not body.consent:
        raise HTTPException(400, "Please tick the consent box to save your photos with the order.")
    if not ID_RE.match(body.preview_id):
        raise HTTPException(400, "Invalid preview id.")
    name, phone = body.customer_name.strip(), body.phone.strip()
    if not name or not re.match(r"^[0-9+()\-\s]{6,20}$", phone):
        raise HTTPException(400, "Please enter your name and a valid phone number.")
    due = body.due_date.strip()
    if due and not _valid_date(due):
        raise HTTPException(400, "The needed-by date must look like 2026-12-31.")
    meta_file = OUT_DIR / f"{body.preview_id}.json"
    if not meta_file.exists():
        raise HTTPException(404, "Preview expired. Please generate it again.")
    meta = json.loads(meta_file.read_text())
    order_id = db.create_order(body.preview_id, name[:100], phone, body.notes[:500], meta, due)
    log.info("order #%s created", order_id)
    return {"order_id": order_id}


class TrackIn(BaseModel):
    order_id: int
    phone: str


@app.post("/api/track", dependencies=[Depends(rate_limit("track", 10))])
def api_track(body: TrackIn):
    """Customer-facing order status. Needs the order number AND the phone number used for the order."""
    o = db.find_for_tracking(body.order_id, body.phone)
    if not o:
        raise HTTPException(404, "No order found with that number and phone. Check both and try again.")
    return {
        "id": o["id"],
        "customer_name": o["customer_name"],
        "status": o["status"],
        "created_at": o["created_at"],
        "updated_at": o.get("updated_at"),
        "delivery_date": o.get("delivery_date"),
        "price": o.get("price"),
        "advance": o.get("advance"),
        "balance": o.get("balance"),
        "garment_label": garments.GARMENTS.get(o["garment"], {}).get("label", o["garment"]),
        "spec_rows": garments.describe_spec(garments.normalize_spec(o["spec"])),
        "extras": o["spec"].get("extras", []),
        "preview_url": _images(o["preview_id"])["preview_url"],
        "shop": shop_info(),
    }


# --------------------------------------------------------------------------- tailor API


def _decorate(o):
    o.update(_images(o["preview_id"]))
    o["garment_label"] = garments.GARMENTS.get(o["garment"], {}).get("label", o["garment"])
    o["spec_rows"] = garments.describe_spec(garments.normalize_spec(o["spec"]))
    o["extras"] = o["spec"].get("extras", [])
    return o


@app.get("/api/admin/check", dependencies=[Depends(rate_limit("admin", 20)), Depends(admin_auth)])
def api_admin_check():
    return {"ok": True}


@app.get("/api/stats", dependencies=[Depends(admin_auth)])
def api_stats():
    return db.stats()


@app.get("/api/orders", dependencies=[Depends(admin_auth)])
def api_list_orders(status: str = "all", q: str = ""):
    if status != "all" and status not in db.STATUSES:
        raise HTTPException(400, "Unknown status.")
    return [_decorate(o) for o in db.list_orders(status=status, q=q[:60])]


def _csv_safe(value):
    """Stops spreadsheet programs from running a customer's text as a formula."""
    text = "" if value is None else str(value)
    return "'" + text if text[:1] in ("=", "+", "-", "@", "\t", "\r") else text


@app.get("/api/orders.csv", dependencies=[Depends(admin_auth)])
def api_orders_csv(status: str = "all", q: str = ""):
    """All matching orders as a spreadsheet file (opens in Excel with Hindi/Marathi names intact)."""
    if status != "all" and status not in db.STATUSES:
        raise HTTPException(400, "Unknown status.")
    buf = io.StringIO()
    out = csv.writer(buf)
    out.writerow(["Order", "Placed", "Customer", "Phone", "Garment", "Status", "Needed by", "Promised delivery",
                  "Total", "Advance", "Balance", "Customer note", "Workshop note"])
    for o in db.list_orders(status=status, q=q[:60], limit=100000):
        label = garments.GARMENTS.get(o["garment"], {}).get("label", o["garment"])
        out.writerow([o["id"], o["created_at"], _csv_safe(o["customer_name"]), _csv_safe(o["phone"]), label,
                      o["status"], o.get("due_date") or "", o.get("delivery_date") or "",
                      "" if o.get("price") is None else o["price"], "" if o.get("advance") is None else o["advance"],
                      "" if o.get("balance") is None else o["balance"], _csv_safe(o["notes"]),
                      _csv_safe(o["tailor_notes"])])
    name = f"orders-{date.today().isoformat()}.csv"
    return Response("\ufeff" + buf.getvalue(), media_type="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="{name}"'})


@app.get("/api/orders/{order_id}", dependencies=[Depends(admin_auth)])
def api_get_order(order_id: int):
    o = db.get_order(order_id)
    if not o:
        raise HTTPException(404, "Order not found.")
    return _decorate(o)


class OrderUpdate(BaseModel):
    status: Optional[str] = None
    delivery_date: Optional[str] = None  # YYYY-MM-DD, "" clears
    price: Optional[float] = None
    advance: Optional[float] = None
    tailor_notes: Optional[str] = None


@app.patch("/api/orders/{order_id}", dependencies=[Depends(admin_auth)])
def api_update_order(order_id: int, body: OrderUpdate):
    if not db.get_order(order_id):
        raise HTTPException(404, "Order not found.")
    changes = body.model_dump(exclude_unset=True)
    if "status" in changes and changes["status"] not in db.STATUSES:
        raise HTTPException(400, "Unknown status.")
    if changes.get("delivery_date") and not _valid_date(changes["delivery_date"]):
        raise HTTPException(400, "Delivery date must look like 2026-12-31.")
    for k in ("price", "advance"):
        if changes.get(k) is not None and not (0 <= changes[k] <= 10_000_000):
            raise HTTPException(400, "Amounts must be between 0 and 10,000,000.")
    if "tailor_notes" in changes:
        changes["tailor_notes"] = (changes["tailor_notes"] or "")[:2000]
    db.update_order(order_id, changes)
    return _decorate(db.get_order(order_id))


@app.delete("/api/orders/{order_id}", dependencies=[Depends(admin_auth)])
def api_delete_order(order_id: int):
    o = db.get_order(order_id)
    if not o:
        raise HTTPException(404, "Order not found.")
    db.delete_order(order_id)
    _delete_preview_files(o["preview_id"])
    log.info("order #%s deleted", order_id)
    return {"ok": True}


# --------------------------------------------------------------------------- static
# Only the two photo folders are public. The data folder also holds the orders database.

app.mount("/files/outputs", StaticFiles(directory=OUT_DIR), name="files-outputs")
app.mount("/files/uploads", StaticFiles(directory=UP_DIR), name="files-uploads")
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")


@app.exception_handler(404)
async def not_found(request: Request, exc):
    if request.url.path.startswith(("/api/", "/files/")):
        detail = getattr(exc, "detail", "Not found")
        return JSONResponse({"detail": detail if detail != "Not Found" else "Not found."}, status_code=404)
    return FileResponse(BASE_DIR / "static" / "404.html", status_code=404)


@app.get("/", include_in_schema=False)
def home():
    return FileResponse(BASE_DIR / "static" / "index.html")


@app.get("/track", include_in_schema=False)
def track_page():
    return FileResponse(BASE_DIR / "static" / "track.html")


@app.get("/staff", include_in_schema=False)
def staff_page():
    return FileResponse(BASE_DIR / "static" / "orders.html")


@app.get("/orders", include_in_schema=False)
def orders_page():
    return RedirectResponse("/staff")
