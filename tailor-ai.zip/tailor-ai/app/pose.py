"""Body landmark detection.

Order of preference:
  1. MediaPipe "solutions" Pose (older mediapipe 0.10.x releases) - model is bundled.
  2. MediaPipe "tasks" PoseLandmarker (newer mediapipe) - needs a small model file
     (pose_landmarker_full.task, ~9 MB). It is downloaded once to data/models/ on first use,
     or set TAILOR_POSE_MODEL to a local copy of the file.
  3. A standard standing-body layout, so the app still produces a preview (the user is told
     that the fit is approximate).

All points are returned in image pixel coordinates as numpy arrays.
"left" / "right" mean the LEFT / RIGHT SIDE OF THE IMAGE (smaller / larger x).
"""
import os
import threading
import time
import urllib.request
from pathlib import Path

import cv2
import numpy as np

try:  # optional dependency
    import mediapipe as mp
except Exception:  # pragma: no cover - depends on the machine
    mp = None

_HAS_SOLUTIONS = bool(mp is not None and hasattr(mp, "solutions"))
_HAS_TASKS = False
if mp is not None and not _HAS_SOLUTIONS:
    try:
        from mediapipe.tasks.python import BaseOptions as _BaseOptions
        from mediapipe.tasks.python import vision as _vision

        _HAS_TASKS = hasattr(_vision, "PoseLandmarker")
    except Exception:  # pragma: no cover
        _HAS_TASKS = False

MODEL_URL = ("https://storage.googleapis.com/mediapipe-models/pose_landmarker/"
             "pose_landmarker_full/float16/latest/pose_landmarker_full.task")

_lock = threading.Lock()
_landmarker = None
_last_error = ""
_retry_after = 0.0


def engine() -> str:
    if _HAS_SOLUTIONS:
        return "mediapipe-solutions"
    if _HAS_TASKS:
        return "mediapipe-tasks"
    return "fallback"


def mediapipe_available() -> bool:
    return engine() != "fallback"


def last_error() -> str:
    return _last_error


# --------------------------------------------------------------------------- fallback


def _fallback(w: int, h: int) -> dict:
    """A centred, upright, full-body layout used when pose detection is unavailable."""
    top = 0.04 * h
    body_h = 0.92 * h

    def y(f):
        return top + f * body_h

    cx = w / 2.0
    sw = min(0.38 * w, 0.2 * h)  # shoulder width
    hw = sw * 0.55  # hip joint distance
    return {
        "nose": np.array([cx, y(0.07)]),
        "sh_l": np.array([cx - sw / 2, y(0.19)]),
        "sh_r": np.array([cx + sw / 2, y(0.19)]),
        "el_l": np.array([cx - sw / 2 - 0.05 * sw, y(0.38)]),
        "el_r": np.array([cx + sw / 2 + 0.05 * sw, y(0.38)]),
        "wr_l": np.array([cx - sw / 2 - 0.10 * sw, y(0.55)]),
        "wr_r": np.array([cx + sw / 2 + 0.10 * sw, y(0.55)]),
        "hip_l": np.array([cx - hw / 2, y(0.52)]),
        "hip_r": np.array([cx + hw / 2, y(0.52)]),
        "kn_l": np.array([cx - hw / 2, y(0.74)]),
        "kn_r": np.array([cx + hw / 2, y(0.74)]),
        "an_l": np.array([cx - hw / 2, y(0.96)]),
        "an_r": np.array([cx + hw / 2, y(0.96)]),
    }


# --------------------------------------------------------------------------- mediapipe


def _keypoints_from_landmarks(lm, w, h):
    """33 MediaPipe landmarks -> our keypoint dict, or None if the shoulders look unreliable."""
    # MediaPipe's "left" is the person's left; pick which index sits on the image-left side.
    off_l = 1 if lm[11].x > lm[12].x else 0
    off_r = 1 - off_l

    def pt(base, off):
        p = lm[base + off]
        return np.array([p.x * w, p.y * h])

    kp = {
        "nose": np.array([lm[0].x * w, lm[0].y * h]),
        "sh_l": pt(11, off_l), "sh_r": pt(11, off_r),
        "el_l": pt(13, off_l), "el_r": pt(13, off_r),
        "wr_l": pt(15, off_l), "wr_r": pt(15, off_r),
        "hip_l": pt(23, off_l), "hip_r": pt(23, off_r),
        "kn_l": pt(25, off_l), "kn_r": pt(25, off_r),
        "an_l": pt(27, off_l), "an_r": pt(27, off_r),
    }
    vis = min(getattr(lm[11], "visibility", 1.0) or 0.0, getattr(lm[12], "visibility", 1.0) or 0.0)
    sw = abs(kp["sh_r"][0] - kp["sh_l"][0])
    if vis > 0.4 and sw > 0.04 * w:
        return kp
    return None


def _model_path() -> Path:
    custom = os.getenv("TAILOR_POSE_MODEL")
    if custom:
        return Path(custom)
    base = Path(os.getenv("TAILOR_DATA_DIR", Path(__file__).resolve().parent.parent / "data"))
    return base / "models" / "pose_landmarker_full.task"


def _get_landmarker():
    """Create (once) the tasks-API landmarker, downloading the model if needed."""
    global _landmarker, _last_error, _retry_after
    if _landmarker is not None:
        return _landmarker
    if time.time() < _retry_after:
        return None
    path = _model_path()
    try:
        if not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp = path.with_suffix(".part")
            with urllib.request.urlopen(MODEL_URL, timeout=60) as r, open(tmp, "wb") as f:
                f.write(r.read())
            tmp.replace(path)
        opts = _vision.PoseLandmarkerOptions(
            base_options=_BaseOptions(model_asset_path=str(path)),
            running_mode=_vision.RunningMode.IMAGE,
            num_poses=1,
            min_pose_detection_confidence=0.4,
        )
        _landmarker = _vision.PoseLandmarker.create_from_options(opts)
        _last_error = ""
    except Exception as e:  # network blocked, corrupt file, ...
        _last_error = f"{type(e).__name__}: {e}"
        _retry_after = time.time() + 300  # do not hammer the network on every request
        return None
    return _landmarker


def _detect_solutions(img_bgr):
    h, w = img_bgr.shape[:2]
    with mp.solutions.pose.Pose(static_image_mode=True, model_complexity=1,
                                min_detection_confidence=0.4) as pose:
        res = pose.process(cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB))
    if res.pose_landmarks:
        return _keypoints_from_landmarks(res.pose_landmarks.landmark, w, h)
    return None


def _detect_tasks(img_bgr):
    h, w = img_bgr.shape[:2]
    with _lock:
        lmk = _get_landmarker()
        if lmk is None:
            return None
        rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
        image = mp.Image(image_format=mp.ImageFormat.SRGB, data=np.ascontiguousarray(rgb))
        res = lmk.detect(image)
    if res.pose_landmarks:
        return _keypoints_from_landmarks(res.pose_landmarks[0], w, h)
    return None


def detect_landmarks(img_bgr):
    """Return (keypoints, detected). `detected` is False when the fallback layout is used."""
    h, w = img_bgr.shape[:2]
    global _last_error
    try:
        kp = None
        if _HAS_SOLUTIONS:
            kp = _detect_solutions(img_bgr)
        elif _HAS_TASKS:
            kp = _detect_tasks(img_bgr)
        if kp is not None:
            return kp, True
    except Exception as e:
        _last_error = f"{type(e).__name__}: {e}"
    return _fallback(w, h), False
