"""SQLite store for saved orders."""
import json
import re
import sqlite3
import time
from contextlib import contextmanager
from datetime import date, timedelta
from pathlib import Path

_PATH = None

SCHEMA = """
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    preview_id TEXT NOT NULL,
    customer_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    notes TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'new',
    garment TEXT,
    spec_json TEXT,
    description TEXT,
    instructions TEXT,
    measurements_json TEXT
);
"""

# Columns added after the first release. Existing databases are upgraded automatically.
EXTRA_COLUMNS = {
    "delivery_date": "TEXT",
    "price": "REAL",
    "advance": "REAL",
    "tailor_notes": "TEXT DEFAULT ''",
    "updated_at": "TEXT",
    "due_date": "TEXT",  # date the customer asked for (delivery_date is what the tailor promises)
}

STATUSES = ["new", "confirmed", "cutting", "stitching", "ready", "delivered", "cancelled"]
OPEN_STATUSES = ["new", "confirmed", "cutting", "stitching"]
EDITABLE = {"status", "delivery_date", "price", "advance", "tailor_notes"}


def init(data_dir):
    global _PATH
    _PATH = Path(data_dir) / "orders.db"
    with _conn() as c:
        c.executescript(SCHEMA)
        have = {r["name"] for r in c.execute("PRAGMA table_info(orders)")}
        for col, typ in EXTRA_COLUMNS.items():
            if col not in have:
                c.execute(f"ALTER TABLE orders ADD COLUMN {col} {typ}")


@contextmanager
def _conn():
    con = sqlite3.connect(_PATH)
    con.row_factory = sqlite3.Row
    try:
        yield con
        con.commit()
    finally:
        con.close()


def digits(phone: str) -> str:
    return re.sub(r"\D", "", phone or "")


def _row(r):
    if r is None:
        return None
    d = dict(r)
    d["spec"] = json.loads(d.pop("spec_json") or "{}")
    d["measurements"] = json.loads(d.pop("measurements_json") or "null")
    d["tailor_notes"] = d.get("tailor_notes") or ""
    price, adv = d.get("price"), d.get("advance")
    d["balance"] = None if price is None else max(price - (adv or 0), 0)
    return d


def create_order(preview_id, name, phone, notes, meta, due_date=""):
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    with _conn() as c:
        cur = c.execute(
            "INSERT INTO orders (created_at, updated_at, preview_id, customer_name, phone, notes, garment,"
            " spec_json, description, instructions, measurements_json, due_date) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (now, now, preview_id, name, phone, notes, meta["spec"]["garment"], json.dumps(meta["spec"]),
             meta.get("description", ""), meta.get("instructions", ""),
             json.dumps(meta.get("measurements")), due_date or None),
        )
        return cur.lastrowid


def list_orders(status=None, q=None, limit=500):
    sql, args = "SELECT * FROM orders", []
    where = []
    if status and status != "all":
        where.append("status = ?")
        args.append(status)
    if q:
        q = q.strip()
        like = f"%{q}%"
        clause = "(customer_name LIKE ? OR phone LIKE ?"
        args += [like, like]
        if q.lstrip("#").isdigit():
            clause += " OR id = ?"
            args.append(int(q.lstrip("#")))
        where.append(clause + ")")
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY id DESC LIMIT ?"
    args.append(limit)
    with _conn() as c:
        return [_row(r) for r in c.execute(sql, args)]


def get_order(order_id):
    with _conn() as c:
        return _row(c.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone())


def update_order(order_id, fields: dict):
    fields = {k: v for k, v in fields.items() if k in EDITABLE}
    if not fields:
        return
    fields["updated_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    cols = ", ".join(f"{k}=?" for k in fields)
    with _conn() as c:
        c.execute(f"UPDATE orders SET {cols} WHERE id=?", (*fields.values(), order_id))


def delete_order(order_id):
    with _conn() as c:
        c.execute("DELETE FROM orders WHERE id=?", (order_id,))


def preview_ids_in_orders():
    with _conn() as c:
        return {r["preview_id"] for r in c.execute("SELECT preview_id FROM orders")}


def find_for_tracking(order_id, phone):
    """Order lookup for customers: the order number AND the phone number must match."""
    o = get_order(order_id)
    mine, given = digits(o["phone"]) if o else "", digits(phone)
    if not o or len(given) < 6 or mine[-10:] != given[-10:]:
        return None
    return o


def stats():
    today = date.today()
    soon = (today + timedelta(days=7)).isoformat()
    with _conn() as c:
        counts = {s: 0 for s in STATUSES}
        for r in c.execute("SELECT status, COUNT(*) n FROM orders GROUP BY status"):
            counts[r["status"]] = r["n"]
        marks = ",".join("?" * len(OPEN_STATUSES + ["ready"]))
        open_like = OPEN_STATUSES + ["ready"]
        overdue = c.execute(
            f"SELECT COUNT(*) FROM orders WHERE COALESCE(NULLIF(delivery_date, ''), due_date) < ? "
            f"AND COALESCE(NULLIF(delivery_date, ''), due_date) IS NOT NULL AND status IN ({marks})", (today.isoformat(), *open_like)).fetchone()[0]
        due_soon = c.execute(
            f"SELECT COUNT(*) FROM orders WHERE COALESCE(NULLIF(delivery_date, ''), due_date) >= ? "
            f"AND COALESCE(NULLIF(delivery_date, ''), due_date) <= ? "
            f"AND status IN ({marks})", (today.isoformat(), soon, *open_like)).fetchone()[0]
    return {"counts": counts, "total": sum(counts.values()), "overdue": overdue, "due_soon": due_soon}
