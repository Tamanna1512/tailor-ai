import io
import os
import tempfile

os.environ["TAILOR_DATA_DIR"] = tempfile.mkdtemp()
os.environ.pop("ANTHROPIC_API_KEY", None)
os.environ["TAILOR_ADMIN_KEY"] = "secret"

import cv2  # noqa: E402
import numpy as np  # noqa: E402
import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app import garments, pose, spec_parser  # noqa: E402
from app.main import app  # noqa: E402

client = TestClient(app)


def fake_person(w=600, h=900):
    img = np.full((h, w, 3), (225, 220, 215), np.uint8)
    cv2.circle(img, (300, 110), 45, (150, 175, 215), -1)
    cv2.rectangle(img, (230, 160), (370, 450), (120, 140, 180), -1)
    cv2.rectangle(img, (240, 450), (360, 860), (90, 90, 120), -1)
    return img


def fake_fabric():
    img = np.full((300, 300, 3), (40, 90, 200), np.uint8)
    for i in range(0, 300, 30):
        cv2.line(img, (i, 0), (i, 300), (20, 180, 230), 6)
    return img


def jpg(img):
    ok, buf = cv2.imencode(".jpg", img)
    assert ok
    return io.BytesIO(buf.tobytes())


# ------------------------------------------------------------------ parser


@pytest.mark.parametrize("text,expect", [
    ("A-line kurti, boat neck, 3/4 sleeves, knee length",
     {"garment": "kurta", "fit": "a_line", "neckline": "boat", "sleeve": "three_quarter", "length": "knee"}),
    ("full sleeve shirt with collar, hip length, slim fit",
     {"garment": "shirt", "sleeve": "full", "neckline": "collar", "length": "hip", "fit": "slim"}),
    ("sleeveless v neck blouse crop",
     {"garment": "blouse", "sleeve": "sleeveless", "neckline": "v", "length": "crop"}),
    ("flared lehenga floor length", {"garment": "lehenga", "fit": "a_line", "length": "ankle"}),
    ("patiala salwar", {"garment": "salwar", "fit": "loose"}),
    ("anarkali with mandarin collar and full sleeves",
     {"garment": "kurta", "fit": "a_line", "neckline": "high", "sleeve": "full", "length": "calf"}),
])
def test_rule_parser(text, expect):
    spec = spec_parser.parse_description(text)
    for k, v in expect.items():
        assert spec[k] == v, (text, k, spec)


def test_parser_extras_and_unknown_garment():
    spec = spec_parser.parse_description("something nice with pockets and embroidery")
    assert "pockets" in spec["extras"] and "embroidery" in spec["extras"]
    assert spec["warnings"]  # garment unknown -> warning
    assert spec["garment"] == "kurta"


# ------------------------------------------------------------------ renderer


@pytest.mark.parametrize("garment", list(garments.GARMENTS))
def test_render_every_garment(garment):
    person = fake_person()
    kp, _ = pose.detect_landmarks(person)
    spec = garments.normalize_spec({"garment": garment})
    out, _ = garments.render(person, np.full((64, 64, 3), (40, 90, 200), np.uint8), kp, spec)
    assert out.shape == person.shape
    assert (out != person).any()


@pytest.mark.parametrize("neck", [v for v, _ in garments.OPTIONS["neckline"]])
@pytest.mark.parametrize("sleeve", [v for v, _ in garments.OPTIONS["sleeve"]])
def test_render_neck_sleeve_combos(neck, sleeve):
    person = fake_person()
    kp, _ = pose.detect_landmarks(person)
    spec = garments.normalize_spec({"garment": "kurta", "neckline": neck, "sleeve": sleeve})
    out, _ = garments.render(person, np.full((64, 64, 3), 200, np.uint8), kp, spec)
    assert (out != person).any()


# ------------------------------------------------------------------ API


def test_config_and_csv_and_due_date():
    cfg = client.get("/api/config").json()
    assert "shop" in cfg and "statuses" in cfg and cfg["admin_protected"] is True

    files = {"person": ("p.jpg", jpg(fake_person()), "image/jpeg")}
    d = client.post("/api/preview", files=files, data={"mode": "catalog", "garment": "blouse"}).json()
    bad = client.post("/api/orders", json={"preview_id": d["id"], "customer_name": "=HYPERLINK(1)",
                                           "phone": "9876543210", "consent": True, "due_date": "tomorrow"})
    assert bad.status_code == 400
    ok = client.post("/api/orders", json={"preview_id": d["id"], "customer_name": "=HYPERLINK(1)",
                                          "phone": "9876543210", "consent": True, "due_date": "2026-12-01"})
    assert ok.status_code == 200
    assert client.get("/api/orders.csv").status_code == 401
    r = client.get("/api/orders.csv", headers={"X-Admin-Key": "secret"})
    assert r.status_code == 200 and r.headers["content-type"].startswith("text/csv")
    assert "'=HYPERLINK(1)" in r.text and "2026-12-01" in r.text  # formula is neutralised
    oid = ok.json()["order_id"]
    assert client.get(f"/api/orders/{oid}", headers={"X-Admin-Key": "secret"}).json()["due_date"] == "2026-12-01"


def test_catalog():
    r = client.get("/api/catalog")
    assert r.status_code == 200
    assert {g["id"] for g in r.json()["garments"]} == set(garments.GARMENTS)


def test_preview_catalog_and_order_flow():
    files = {"person": ("p.jpg", jpg(fake_person()), "image/jpeg"),
             "fabric": ("f.jpg", jpg(fake_fabric()), "image/jpeg")}
    r = client.post("/api/preview", files=files,
                    data={"mode": "catalog", "garment": "kurta", "neckline": "v", "sleeve": "full",
                          "length": "knee", "fit": "regular", "fabric_crop": "0.1,0.1,0.5,0.5"})
    assert r.status_code == 200, r.text
    d = r.json()
    assert client.get(d["preview_url"]).status_code == 200
    assert d["spec"]["neckline"] == "v"

    # consent is required
    bad = client.post("/api/orders", json={"preview_id": d["id"], "customer_name": "Asha",
                                           "phone": "9876543210", "consent": False})
    assert bad.status_code == 400
    ok = client.post("/api/orders", json={"preview_id": d["id"], "customer_name": "Asha",
                                          "phone": "9876543210", "consent": True})
    assert ok.status_code == 200
    oid = ok.json()["order_id"]

    # dashboard needs the admin key
    assert client.get("/api/orders").status_code == 401
    h = {"X-Admin-Key": "secret"}
    lst = client.get("/api/orders", headers=h)
    assert lst.status_code == 200 and lst.json()[0]["customer_name"] == "Asha"
    assert client.patch(f"/api/orders/{oid}", json={"status": "stitching"}, headers=h).status_code == 200
    assert client.delete(f"/api/orders/{oid}", headers=h).status_code == 200
    assert client.get(d["preview_url"]).status_code == 404  # photos erased with the order


def test_preview_custom_text_without_fabric_file():
    files = {"person": ("p.jpg", jpg(fake_person()), "image/jpeg")}
    r = client.post("/api/preview", files=files,
                    data={"mode": "custom", "description": "sleeveless lehenga flared with border"})
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["spec"]["garment"] == "lehenga" and "border / patti" in d["extras"]


def test_preview_errors():
    files = {"person": ("p.jpg", io.BytesIO(b"not an image"), "image/jpeg")}
    assert client.post("/api/preview", files=files, data={}).status_code == 400
    files = {"person": ("p.jpg", jpg(fake_person()), "image/jpeg")}
    assert client.post("/api/preview", files=files, data={"mode": "custom", "description": " "}).status_code == 400


# ------------------------------------------------------------------ professional features

H = {"X-Admin-Key": "secret"}


def make_order(name="Meera", phone="+91 98765 43210"):
    files = {"person": ("p.jpg", jpg(fake_person()), "image/jpeg")}
    d = client.post("/api/preview", files=files, data={"mode": "catalog", "garment": "blouse"}).json()
    r = client.post("/api/orders", json={"preview_id": d["id"], "customer_name": name, "phone": phone, "consent": True})
    assert r.status_code == 200, r.text
    return r.json()["order_id"], d


def test_config_and_health():
    assert client.get("/healthz").json() == {"ok": True}
    c = client.get("/api/config").json()
    assert c["admin_required"] is True and c["shop"]["name"]


def test_database_and_models_are_not_downloadable():
    assert client.get("/files/orders.db").status_code == 404
    assert client.get("/files/outputs/../orders.db").status_code in (400, 404)
    assert client.get("/files/models/pose_landmarker_full.task").status_code == 404


def test_security_headers():
    r = client.get("/api/config")
    assert r.headers["x-content-type-options"] == "nosniff"
    assert r.headers["x-frame-options"] == "SAMEORIGIN"
    assert r.headers["cache-control"] == "no-store"


def test_pages_load():
    for path in ["/", "/track", "/staff", "/static/job.html", "/static/style.css", "/static/common.js",
                 "/static/fonts/bricolage-grotesque-latin-wght-normal.woff2"]:
        assert client.get(path).status_code == 200, path
    assert client.get("/no-such-page").status_code == 404
    assert "couldn" in client.get("/no-such-page").text


def test_edit_order_and_stats():
    oid, _ = make_order()
    r = client.patch(f"/api/orders/{oid}", headers=H,
                     json={"status": "cutting", "delivery_date": "2020-01-01", "price": 1500, "advance": 500,
                           "tailor_notes": "Use lining"})
    assert r.status_code == 200, r.text
    o = r.json()
    assert o["status"] == "cutting" and o["balance"] == 1000 and o["tailor_notes"] == "Use lining"
    st = client.get("/api/stats", headers=H).json()
    assert st["counts"]["cutting"] >= 1 and st["overdue"] >= 1
    # validation
    assert client.patch(f"/api/orders/{oid}", headers=H, json={"status": "bogus"}).status_code == 400
    assert client.patch(f"/api/orders/{oid}", headers=H, json={"delivery_date": "31/12/2026"}).status_code == 400
    assert client.patch(f"/api/orders/{oid}", headers=H, json={"price": -5}).status_code == 400
    assert client.patch("/api/orders/99999", headers=H, json={"status": "new"}).status_code == 404
    assert client.patch(f"/api/orders/{oid}", json={"status": "new"}).status_code == 401


def test_search_and_filter():
    oid, _ = make_order(name="Zainab Qureshi", phone="9000011111")
    names = lambda q="", status="all": [o["customer_name"] for o in client.get(
        "/api/orders", headers=H, params={"q": q, "status": status}).json()]
    assert "Zainab Qureshi" in names("zainab")
    assert "Zainab Qureshi" in names("9000011111")
    assert "Zainab Qureshi" in names(f"#{oid}")
    assert "Zainab Qureshi" not in names("nobody-here")
    assert "Zainab Qureshi" not in names(status="delivered")


def test_customer_tracking():
    main_mod = __import__("app.main", fromlist=["_hits"])
    main_mod._hits.clear()
    oid, d = make_order(phone="98765 43210")
    ok = client.post("/api/track", json={"order_id": oid, "phone": "+91-98765-43210"})
    assert ok.status_code == 200, ok.text
    t = ok.json()
    assert t["status"] == "new" and t["preview_url"].endswith(".jpg") and "phone" not in t
    assert "instructions" not in t  # tailor-only data is not exposed
    assert client.post("/api/track", json={"order_id": oid, "phone": "9999999999"}).status_code == 404
    assert client.post("/api/track", json={"order_id": 424242, "phone": "9876543210"}).status_code == 404


def test_tracking_is_rate_limited():
    main_mod = __import__("app.main", fromlist=["_hits"])
    main_mod._hits.clear()
    codes = [client.post("/api/track", json={"order_id": 1, "phone": f"900000000{i}"}).status_code for i in range(14)]
    assert 429 in codes
    main_mod._hits.clear()


def test_old_database_is_upgraded(tmp_path):
    import sqlite3
    from app import db
    path = tmp_path / "orders.db"
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE orders (id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, preview_id TEXT NOT NULL,"
                " customer_name TEXT NOT NULL, phone TEXT NOT NULL, notes TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'new',"
                " garment TEXT, spec_json TEXT, description TEXT, instructions TEXT, measurements_json TEXT)")
    con.commit(); con.close()
    keep = db._PATH
    try:
        db.init(tmp_path)
        con = sqlite3.connect(path)
        cols = {r[1] for r in con.execute("PRAGMA table_info(orders)")}
        con.close()
        assert {"delivery_date", "price", "advance", "tailor_notes", "updated_at"} <= cols
    finally:
        db._PATH = keep
