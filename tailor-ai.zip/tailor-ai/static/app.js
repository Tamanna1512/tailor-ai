"use strict";
/* Customer design studio. Needs common.js. */

const FIELDS = [["neckline", "Neckline"], ["sleeve", "Sleeves"], ["length", "Length"], ["fit", "Fit"]];
const EXAMPLES = [
  "A-line kurti, boat neck, 3/4 sleeves, knee length",
  "Full sleeve shirt with collar, hip length, slim fit",
  "Sleeveless blouse, V neck, crop length",
  "Flared lehenga, floor length, with border",
];

const state = {
  catalog: null, mode: "catalog",
  person: null, personUrl: "", fabric: null, fabricUrl: "",
  crop: null, cropping: false,
  result: null, busy: false, savedId: null,
};

// ------------------------------------------------------------------ setup
function fillIcons() {
  $$("[data-icon]").forEach((n) => { n.innerHTML = ICON[n.dataset.icon] || ""; n.style.display = "inline-flex"; });
}

async function init() {
  fillIcons();
  await loadConfig();
  const cat = await (await fetch("/api/catalog")).json();
  state.catalog = cat;

  const grid = $("#garmentGrid");
  cat.garments.forEach((g, i) => {
    grid.append(el("label", { class: "gcard" },
      el("input", { type: "radio", name: "garment", value: g.id, checked: i === 0 }),
      (() => { const s = el("span"); s.innerHTML = garmentSvg(g.id); s.append(g.label.split(" / ")[0]); return s; })()));
  });
  grid.addEventListener("change", applyGarment);

  const groups = $("#optionGroups");
  FIELDS.forEach(([f, label]) => {
    const pills = el("div", { class: "pills" });
    cat.options[f].forEach((o) => pills.append(el("label", { class: "pill" },
      el("input", { type: "radio", name: f, value: o.value }), el("span", { text: o.label }))));
    groups.append(el("fieldset", { "data-field": f }, el("legend", { text: label }), pills));
  });
  applyGarment();

  EXAMPLES.forEach((t) => $("#examples").append(el("button", { type: "button", text: t, onclick: () => { $("#description").value = t; $("#description").focus(); } })));

  if (cat.pose_engine === "fallback") {
    setMsg($("#status"), "Body detection is not installed on this server, so the fit will be approximate.", "");
  }
  const s = CONFIG.shop;
  if (s.whatsapp) $("#waShop").hidden = false;
  renderStage();
}

function selectedGarment() {
  const r = $("input[name=garment]:checked");
  return state.catalog.garments.find((g) => g.id === (r ? r.value : "kurta"));
}

function applyGarment() {
  const g = selectedGarment();
  $$("#optionGroups fieldset").forEach((fs) => {
    const f = fs.dataset.field;
    const on = g.applies.includes(f);
    fs.hidden = !on;
    if (on) {
      const r = $(`input[value="${g.defaults[f]}"]`, fs);
      if (r) r.checked = true;
    }
  });
}

// ------------------------------------------------------------------ tabs
function setMode(m) {
  state.mode = m;
  $("#tabCatalog").setAttribute("aria-selected", String(m === "catalog"));
  $("#tabCustom").setAttribute("aria-selected", String(m === "custom"));
  $("#panelCatalog").hidden = m !== "catalog";
  $("#panelCustom").hidden = m !== "custom";
}
$("#tabCatalog").onclick = () => setMode("catalog");
$("#tabCustom").onclick = () => setMode("custom");

// ------------------------------------------------------------------ photos
function setPerson(file) {
  if (!file) return;
  if (!file.type.startsWith("image/")) { setMsg($("#status"), "That file is not an image. Choose a JPG or PNG photo.", "err"); return; }
  if (state.personUrl) URL.revokeObjectURL(state.personUrl);
  state.person = file;
  state.personUrl = URL.createObjectURL(file);
  state.crop = null; state.cropping = false; state.result = null; state.savedId = null;
  $("#beforeImg").src = state.personUrl;
  $("#personThumb").style.backgroundImage = `url("${state.personUrl}")`;
  $("#personThumb").classList.add("has");
  $("#personName").textContent = file.name || "Photo added";
  $("#resultStep").hidden = true;
  $("#saveStep").hidden = true;
  setMsg($("#status"), "", "");
  renderStage();
}

function setFabric(file) {
  if (!file) return;
  if (!file.type.startsWith("image/")) { setMsg($("#status"), "That file is not an image.", "err"); return; }
  if (state.fabricUrl) URL.revokeObjectURL(state.fabricUrl);
  state.fabric = file;
  state.fabricUrl = URL.createObjectURL(file);
  state.crop = null; state.cropping = false;
  $("#fabricThumb").style.backgroundImage = `url("${state.fabricUrl}")`;
  $("#fabricThumb").classList.add("has");
  $("#fabricName").textContent = file.name || "Cloth photo added";
  $("#clothHelp").textContent = "The cloth is taken from the middle of the close-up. Take it flat, in good light, filling the frame.";
  renderStage();
}

["#pickPhoto", "#pickPhoto2", "#changePhoto"].forEach((s) => { $(s).onclick = () => $("#personInput").click(); });
$("#pickFabric").onclick = () => $("#fabricInput").click();
$("#personInput").addEventListener("change", (e) => { setPerson(e.target.files[0]); e.target.value = ""; });
$("#fabricInput").addEventListener("change", (e) => { setFabric(e.target.files[0]); e.target.value = ""; });

(function dropZone() {
  const f = $("#stageFrame");
  ["dragenter", "dragover"].forEach((ev) => f.addEventListener(ev, (e) => { e.preventDefault(); f.classList.add("drag"); }));
  ["dragleave", "drop"].forEach((ev) => f.addEventListener(ev, (e) => { e.preventDefault(); f.classList.remove("drag"); }));
  f.addEventListener("drop", (e) => { const file = e.dataTransfer.files[0]; if (file) setPerson(file); });
})();

/* Shrinks big phone photos before upload (faster on mobile data). Falls back to the original file. */
async function prepare(file, max) {
  try {
    const bmp = await createImageBitmap(file, { imageOrientation: "from-image" });
    const s = Math.min(1, max / Math.max(bmp.width, bmp.height));
    const c = document.createElement("canvas");
    c.width = Math.round(bmp.width * s); c.height = Math.round(bmp.height * s);
    c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
    if (bmp.close) bmp.close();
    const blob = await new Promise((r) => c.toBlob(r, "image/jpeg", 0.9));
    return blob ? new File([blob], "photo.jpg", { type: "image/jpeg" }) : file;
  } catch (e) { return file; }
}

// ------------------------------------------------------------------ stage
function renderStage() {
  const has = !!state.person;
  $("#stageEmpty").hidden = has;
  $("#photoWrap").hidden = !has;
  const showResult = !!state.result && !state.cropping && !state.busy;
  $("#afterImg").hidden = !showResult;
  $("#divider").hidden = !showResult;
  $("#compareBar").hidden = !showResult;
  $("#photoWrap").classList.toggle("scanning", state.busy);
  $("#photoWrap").classList.toggle("cropping", state.cropping);
  $("#changePhoto").hidden = !has;
  $("#cropBtn").hidden = !has || !!state.fabric;
  $("#cropBtn").setAttribute("aria-pressed", String(state.cropping));
  $("#cropBtn").lastChild.textContent = state.cropping ? "Done selecting" : (state.crop ? "Change cloth area" : "Select cloth area");
  $("#downloadCard").hidden = !state.result;
  $("#shareCard").hidden = !state.result;
  const hint = $("#stageHint");
  hint.hidden = !state.cropping;
  hint.textContent = state.cropping ? "Drag on the photo to mark a flat, well-lit part of the cloth, then press Done selecting." : "";
  const note = $("#stageNote");
  note.hidden = !state.busy;
  note.textContent = state.busy ? "Stitching your preview" : "";
  $("#cropRect").style.display = state.crop && (state.cropping || !state.result) ? "block" : "none";
  if (has) fitPhoto();
  if (showResult) setSlider(+$("#slider").value);
}

/* Sizes the photo to fit the stage and the screen height while keeping its proportions. */
function fitPhoto() {
  const img = $("#beforeImg");
  if (!img.naturalWidth) return;
  const availW = $("#stageFrame").clientWidth - 2;
  const maxH = Math.min(window.innerHeight * 0.74, 760);
  const s = Math.min(availW / img.naturalWidth, maxH / img.naturalHeight);
  $("#photoWrap").style.width = Math.floor(img.naturalWidth * s) + "px";
}
$("#beforeImg").addEventListener("load", fitPhoto);
window.addEventListener("resize", fitPhoto);

function setSlider(v) {
  $("#afterImg").style.clipPath = `inset(0 0 0 ${v}%)`;
  $("#divider").style.left = v + "%";
}
$("#slider").addEventListener("input", (e) => setSlider(+e.target.value));

// cloth-area selection on the photo
(function cropper() {
  const host = $("#photoWrap"), img = $("#beforeImg"), rectEl = $("#cropRect");
  let start = null;
  const clamp = (v) => Math.min(Math.max(v, 0), 1);
  const pos = (e) => { const r = img.getBoundingClientRect(); return { x: clamp((e.clientX - r.left) / r.width), y: clamp((e.clientY - r.top) / r.height) }; };
  function draw(a, b) {
    const r = { x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), w: Math.abs(a.x - b.x), h: Math.abs(a.y - b.y) };
    Object.assign(rectEl.style, { display: "block", left: r.x * 100 + "%", top: r.y * 100 + "%", width: r.w * 100 + "%", height: r.h * 100 + "%" });
    return r;
  }
  host.addEventListener("pointerdown", (e) => {
    if (!state.cropping) return;
    start = pos(e); host.setPointerCapture(e.pointerId); state.crop = null; draw(start, start);
  });
  host.addEventListener("pointermove", (e) => { if (start) state.crop = draw(start, pos(e)); });
  host.addEventListener("pointerup", () => {
    start = null;
    if (state.crop && (state.crop.w < 0.03 || state.crop.h < 0.03)) { state.crop = null; rectEl.style.display = "none"; }
  });
})();
$("#cropBtn").onclick = () => { state.cropping = !state.cropping; renderStage(); };

// ------------------------------------------------------------------ voice input
(function mic() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const btn = $("#micBtn");
  if (!SR) { btn.hidden = true; $("#micLang").hidden = true; return; }
  btn.onclick = () => {
    const rec = new SR();
    rec.lang = $("#micLang").value;
    rec.interimResults = false;
    $("#micLabel").textContent = "Listening";
    rec.onresult = (e) => { const d = $("#description"); const t = e.results[0][0].transcript; d.value = d.value ? d.value + " " + t : t; };
    const end = () => { $("#micLabel").textContent = "Speak it"; };
    rec.onend = end;
    rec.onerror = () => { end(); toast("Could not hear you. Check the microphone permission.", "err"); };
    rec.start();
  };
})();

// ------------------------------------------------------------------ preview
$("#generateBtn").onclick = async () => {
  const status = $("#status");
  if (!state.person) { setMsg(status, "Add your photo first.", "err"); return; }
  if (state.mode === "custom" && !$("#description").value.trim()) { setMsg(status, "Describe the style you want, or pick one from the catalog.", "err"); return; }
  if (state.cropping) { state.cropping = false; }

  const fd = new FormData();
  fd.append("person", await prepare(state.person, 1600));
  if (state.fabric) fd.append("fabric", await prepare(state.fabric, 1200));
  else if (state.crop) fd.append("fabric_crop", [state.crop.x, state.crop.y, state.crop.w, state.crop.h].map((v) => v.toFixed(4)).join(","));
  fd.append("mode", state.mode);
  fd.append("fabric_scale", $("#fabricScale").value);
  if ($("#heightCm").value) fd.append("height_cm", $("#heightCm").value);
  if (state.mode === "catalog") {
    fd.append("garment", selectedGarment().id);
    $$("#optionGroups fieldset:not([hidden])").forEach((fs) => {
      const r = $("input:checked", fs); if (r) fd.append(fs.dataset.field, r.value);
    });
  } else fd.append("description", $("#description").value);

  const btn = $("#generateBtn");
  btn.disabled = true; state.busy = true; renderStage();
  setMsg(status, "Creating your preview. This takes a few seconds.", "");
  try {
    const res = await fetch("/api/preview", { method: "POST", body: fd });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(typeof data.detail === "string" ? data.detail : "The preview could not be made. Check the photo and try again.");
    state.result = data; state.savedId = null;
    state.busy = false;
    $("#afterImg").src = data.preview_url + "?t=" + Date.now();
    $("#slider").value = 10;
    renderResult(data);
    renderStage();
    setMsg(status, "", "");
    $("#resultStep").scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (err) {
    state.busy = false; renderStage();
    setMsg(status, err.message, "err");
  } finally {
    btn.disabled = false; state.busy = false; renderStage();
  }
};

function renderResult(d) {
  $("#resultStep").hidden = false;
  $("#saveStep").hidden = false;
  $("#saveForm").hidden = false;
  $("#savedBox").hidden = true;
  $("#saveBtn").disabled = false;
  setMsg($("#saveStatus"), "", "");

  const wrap = $("#warnings"); wrap.replaceChildren();
  d.warnings.forEach((w) => wrap.append(el("div", { class: "warn", text: w })));

  const spec = $("#specList"); spec.replaceChildren();
  d.spec_rows.forEach((r) => spec.append(el("dt", { text: r.label }), el("dd", { text: r.value })));
  if (d.extras && d.extras.length) spec.append(el("dt", { text: "For the tailor" }), el("dd", { text: d.extras.join(", ") }));

  $("#swatch").src = d.swatch_url;
  $("#colorText").textContent = "Cloth colour " + d.color;
  $("#instr").textContent = d.instructions;

  const mt = $("#measTable"); mt.replaceChildren();
  if (d.measurements) {
    Object.entries(d.measurements).forEach(([k, v]) => {
      if (!k.endsWith("_cm")) return;
      const name = k.slice(0, -3).replace(/_/g, " ");
      const row = mt.insertRow();
      row.insertCell().textContent = name.charAt(0).toUpperCase() + name.slice(1);
      row.insertCell().textContent = v + " cm";
    });
  }
  $("#measWrap").hidden = !d.measurements;
}

// ------------------------------------------------------------------ design card (drawn in the browser)
const loadImg = (src) => new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = no; i.src = src; });

function wrapText(ctx, text, maxW) {
  const words = text.split(/\s+/); const lines = []; let cur = "";
  words.forEach((w) => { const t = cur ? cur + " " + w : w; if (ctx.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t; });
  if (cur) lines.push(cur);
  return lines;
}

function drawContain(ctx, img, x, y, w, h) {
  const s = Math.min(w / img.width, h / img.height);
  const dw = img.width * s, dh = img.height * s;
  ctx.drawImage(img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
}

async function buildCard(d) {
  const FONT = '"Bricolage Grotesque", "Nirmala UI", "Segoe UI", system-ui, sans-serif';
  try { await Promise.all([document.fonts.load(`700 48px ${FONT}`), document.fonts.load(`400 28px ${FONT}`), document.fonts.load(`600 28px ${FONT}`)]); } catch (e) { /* use fallback font */ }
  const [before, after, swatch] = await Promise.all([loadImg(state.personUrl), loadImg(d.preview_url), loadImg(d.swatch_url)]);
  const shop = CONFIG.shop;
  const W = 1200, P = 48, GAP = 32, IW = (W - 2 * P - GAP) / 2, IH = 700;

  const m = document.createElement("canvas").getContext("2d");
  m.font = `400 26px ${FONT}`;
  const extras = d.extras && d.extras.length ? wrapText(m, "For the tailor: " + d.extras.join(", "), W - 2 * P) : [];
  const rowH = 46;
  const specY = 150 + 22 + 40 + IH + 44;
  const specBottom = specY + Math.max(d.spec_rows.length * rowH, 130);
  const extrasH = extras.length ? 20 + extras.length * 36 : 0;
  const H = specBottom + extrasH + 40 + 100;

  const c = document.createElement("canvas"); c.width = W; c.height = H;
  const ctx = c.getContext("2d");
  ctx.fillStyle = "#f3f5fb"; ctx.fillRect(0, 0, W, H);

  // header
  ctx.fillStyle = "#2a3a8c"; ctx.fillRect(0, 0, W, 150);
  ctx.fillStyle = "#fff"; ctx.textBaseline = "alphabetic";
  ctx.font = `700 54px ${FONT}`; ctx.fillText(shop.name, P, 78);
  ctx.fillStyle = "#cdd3f0"; ctx.font = `400 26px ${FONT}`; ctx.fillText(shop.tagline || "Design preview", P, 118);
  // tape
  ctx.fillStyle = "#f4c542"; ctx.fillRect(0, 150, W, 22);
  ctx.fillStyle = "#161b3d";
  for (let x = 0; x < W; x += 8) ctx.fillRect(x, 150, 1, x % 40 === 0 ? 13 : 6);

  // before / after panels
  const y0 = 150 + 22 + 40;
  [[before, P, "Before"], [after, P + IW + GAP, "After"]].forEach(([img, x, label]) => {
    ctx.fillStyle = "#fff"; ctx.fillRect(x, y0, IW, IH);
    ctx.strokeStyle = "#dde1f1"; ctx.lineWidth = 1; ctx.beginPath();
    for (let gx = 0; gx <= IW; gx += 24) { ctx.moveTo(x + gx + .5, y0); ctx.lineTo(x + gx + .5, y0 + IH); }
    for (let gy = 0; gy <= IH; gy += 24) { ctx.moveTo(x, y0 + gy + .5); ctx.lineTo(x + IW, y0 + gy + .5); }
    ctx.stroke();
    drawContain(ctx, img, x, y0, IW, IH);
    ctx.strokeStyle = "#d6dbec"; ctx.lineWidth = 2; ctx.strokeRect(x, y0, IW, IH);
    ctx.font = `600 24px ${FONT}`;
    const tw = ctx.measureText(label).width + 28;
    ctx.fillStyle = "#161b3d"; ctx.fillRect(x + 14, y0 + 14, tw, 40);
    ctx.fillStyle = "#fff"; ctx.fillText(label, x + 28, y0 + 42);
  });

  // details
  ctx.font = `400 28px ${FONT}`;
  d.spec_rows.forEach((r, i) => {
    const y = specY + i * rowH + 30;
    ctx.fillStyle = "#566080"; ctx.font = `400 28px ${FONT}`; ctx.fillText(r.label, P, y);
    ctx.fillStyle = "#161b3d"; ctx.font = `600 28px ${FONT}`; ctx.fillText(r.value, P + 230, y);
  });
  const sx = W - P - 130;
  ctx.drawImage(swatch, sx, specY, 130, 130);
  ctx.strokeStyle = "#d6dbec"; ctx.lineWidth = 2; ctx.strokeRect(sx, specY, 130, 130);
  ctx.fillStyle = "#566080"; ctx.font = `400 22px ${FONT}`; ctx.textAlign = "right";
  ctx.fillText("Cloth " + d.color, W - P, specY + 160); ctx.textAlign = "left";
  if (extras.length) {
    ctx.fillStyle = "#161b3d"; ctx.font = `400 26px ${FONT}`;
    extras.forEach((ln, i) => ctx.fillText(ln, P, specBottom + 20 + 30 + i * 36));
  }

  // footer
  const fy = H - 100;
  ctx.fillStyle = "#d6dbec"; ctx.fillRect(P, fy, W - 2 * P, 2);
  ctx.fillStyle = "#566080"; ctx.font = `400 22px ${FONT}`;
  ctx.fillText("Preview only. Final fit and drape depend on the tailor.", P, fy + 42);
  const contact = [shop.phone, shop.address].filter(Boolean).join("   ");
  if (contact) { ctx.fillStyle = "#161b3d"; ctx.font = `600 24px ${FONT}`; ctx.fillText(contact, P, fy + 78); }
  return new Promise((ok) => c.toBlob(ok, "image/jpeg", 0.92));
}

function saveBlob(blob, name) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}

function cardName() { return "design-card-" + (selectedGarment().id) + ".jpg"; }

$("#downloadCard").onclick = async () => {
  if (!state.result) return;
  const b = $("#downloadCard"); b.disabled = true;
  try { saveBlob(await buildCard(state.result), cardName()); toast("Design card saved to your device."); }
  catch (e) { toast("Could not make the design card. Try again.", "err"); }
  finally { b.disabled = false; }
};

$("#shareCard").onclick = async () => {
  if (!state.result) return;
  const d = state.result, text = `My design at ${CONFIG.shop.name}: ` + d.spec_rows.map((r) => r.value).join(", ");
  try {
    const blob = await buildCard(d);
    const file = new File([blob], cardName(), { type: "image/jpeg" });
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      try { await navigator.share({ files: [file], text }); return; } catch (e) { if (e.name === "AbortError") return; }
    }
    saveBlob(blob, cardName());
    toast("Design card saved. Attach it in WhatsApp.");
    window.open(waLink("", text), "_blank", "noopener");
  } catch (e) { toast("Could not share the design card.", "err"); }
};

// ------------------------------------------------------------------ send order
(function () { const d = new Date(); $("#custDue").min = new Date(d - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); })();
$("#saveBtn").onclick = async () => {
  if (!state.result) return;
  const btn = $("#saveBtn"), msg = $("#saveStatus");
  const name = $("#custName").value.trim(), phone = $("#custPhone").value.trim();
  if (!name || !phone) { setMsg(msg, "Enter your name and phone number.", "err"); return; }
  if (!$("#consent").checked) { setMsg(msg, "Tick the box to let the shop keep your photos with this order.", "err"); return; }
  btn.disabled = true; setMsg(msg, "Sending...", "");
  try {
    const res = await fetch("/api/orders", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ preview_id: state.result.id, customer_name: name, phone, notes: $("#custNotes").value, due_date: $("#custDue").value, consent: true }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(typeof data.detail === "string" ? data.detail : "Check your name and phone number.");
    state.savedId = data.order_id;
    store("lastOrder", JSON.stringify({ id: data.order_id, phone }));
    $("#saveForm").hidden = true;
    $("#savedBox").hidden = false;
    $("#savedTitle").textContent = `Order #${data.order_id} sent to ${CONFIG.shop.name}`;
    $("#trackLink").href = "/track?order=" + data.order_id;
    if (CONFIG.shop.whatsapp) {
      $("#waShop").href = waLink(CONFIG.shop.whatsapp, `Hi ${CONFIG.shop.name}, I sent order #${data.order_id} (${state.result.spec_rows[0].value}). My name is ${name}.`);
    }
    $("#savedBox").scrollIntoView({ behavior: "smooth", block: "center" });
  } catch (err) {
    setMsg(msg, err.message, "err"); btn.disabled = false;
  }
};

init().catch(() => setMsg($("#status"), "Could not load the catalog. Check that the server is running.", "err"));
