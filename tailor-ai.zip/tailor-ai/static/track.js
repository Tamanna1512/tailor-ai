"use strict";

const STEPS = ["new", "confirmed", "cutting", "stitching", "ready", "delivered"];
const SENTENCE = {
  new: "The shop has your order and will confirm it soon.",
  confirmed: "Your order is confirmed.",
  cutting: "Your cloth is being cut.",
  stitching: "Your outfit is being stitched.",
  ready: "Your outfit is ready. Come and collect it.",
  delivered: "Delivered. Thank you for choosing us.",
  cancelled: "This order was cancelled. Contact the shop if you have questions.",
};

async function lookup() {
  const msg = $("#msg");
  const id = parseInt($("#orderId").value.replace(/\D/g, ""), 10);
  const phone = $("#phone").value.trim();
  if (!id || phone.replace(/\D/g, "").length < 6) { setMsg(msg, "Enter your order number and the phone number you gave the shop.", "err"); return; }
  const btn = $("#go"); btn.disabled = true; setMsg(msg, "Checking...", "");
  try {
    const res = await fetch("/api/track", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ order_id: id, phone }) });
    const d = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(typeof d.detail === "string" ? d.detail : "Could not check the order. Try again.");
    setMsg(msg, "", "");
    show(d);
  } catch (e) {
    $("#result").hidden = true;
    setMsg(msg, e.message, "err");
  } finally { btn.disabled = false; }
}

function show(d) {
  $("#result").hidden = false;
  $("#rTitle").textContent = "Order #" + d.id;
  const b = $("#rBadge"); b.textContent = STATUS_LABEL[d.status] || d.status; b.className = "badge " + d.status;
  $("#rSentence").textContent = SENTENCE[d.status] || "";
  $("#rDue").textContent = d.delivery_date && !["delivered", "cancelled"].includes(d.status) ? "Expected by " + fmtDate(d.delivery_date) : "";

  const tl = $("#timeline"); tl.replaceChildren();
  if (d.status !== "cancelled") {
    const cur = STEPS.indexOf(d.status);
    STEPS.forEach((s, i) => {
      const li = el("li", { class: i < cur ? "done-step" : i === cur ? "now" : "" }, STATUS_LABEL[s]);
      if (i === 0) li.append(el("small", { text: "Placed " + fmtDate(d.created_at) }));
      if (i === cur && d.updated_at && i > 0) li.append(el("small", { text: "Updated " + fmtDate(d.updated_at, true) }));
      if (i === cur) li.setAttribute("aria-current", "step");
      tl.append(li);
    });
  }
  $("#rImg").src = d.preview_url;
  const sp = $("#rSpec"); sp.replaceChildren();
  d.spec_rows.forEach((r) => sp.append(el("dt", { text: r.label }), el("dd", { text: r.value })));
  if (d.extras && d.extras.length) sp.append(el("dt", { text: "For the tailor" }), el("dd", { text: d.extras.join(", ") }));

  const pay = $("#rPay"); pay.replaceChildren();
  if (d.price !== null && d.price !== undefined) {
    [["Total", d.price], ["Paid", d.advance || 0], ["Balance to pay", d.balance]].forEach(([k, v]) => {
      const r = pay.insertRow(); r.insertCell().textContent = k; r.insertCell().textContent = money(v);
    });
    pay.hidden = false;
  } else pay.hidden = true;

  const s = d.shop || CONFIG.shop;
  const call = $("#rCall");
  if (s.phone) { call.href = "tel:" + s.phone.replace(/[^\d+]/g, ""); call.hidden = false; } else call.hidden = true;
  const wa = $("#rWa");
  if (s.whatsapp) { wa.href = waLink(s.whatsapp, `Hi ${s.name}, about my order #${d.id}.`); wa.hidden = false; } else wa.hidden = true;
  $$("[data-icon]").forEach((n) => { n.innerHTML = ICON[n.dataset.icon] || ""; n.style.display = "inline-flex"; });
  $("#result").scrollIntoView({ behavior: "smooth", block: "start" });
}

$("#trackForm").addEventListener("submit", (e) => { e.preventDefault(); lookup(); });

(async function init() {
  await loadConfig("Track order");
  const q = new URLSearchParams(location.search).get("order");
  let last = null;
  try { last = JSON.parse(store("lastOrder") || "null"); } catch (e) { /* ignore */ }
  if (q) $("#orderId").value = q.replace(/\D/g, "");
  else if (last) $("#orderId").value = last.id;
  if (last && String(last.id) === $("#orderId").value) { $("#phone").value = last.phone; lookup(); }
  else if ($("#orderId").value) $("#phone").focus();
})();
