"use strict";
/* Staff dashboard. Needs common.js. */

const OPEN = ["new", "confirmed", "cutting", "stitching", "ready"];
const view = { status: "all", q: "", orders: [], stats: null, current: null };
const todayIso = () => { const d = new Date(); return new Date(d - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); };
const dueOf = (o) => o.delivery_date || o.due_date || "";
const isLate = (o) => dueOf(o) && dueOf(o) < todayIso() && OPEN.includes(o.status);

// ------------------------------------------------------------------ sign in
function showLogin() { $("#board").hidden = true; $("#loginBox").hidden = false; $("#keyInput").focus(); }

$("#loginBox").addEventListener("submit", async (e) => {
  e.preventDefault();
  store("adminKey", $("#keyInput").value);
  setMsg($("#loginMsg"), "Checking...", "");
  try {
    await adminApi("/api/admin/check");
    $("#loginBox").hidden = true;
    start();
  } catch (err) {
    store("adminKey", null);
    setMsg($("#loginMsg"), err.status === 401 ? "That key is not correct." : err.message, "err");
  }
});
$("#logout").addEventListener("click", (e) => { e.preventDefault(); store("adminKey", null); location.reload(); });

// ------------------------------------------------------------------ list
async function load() {
  const qs = new URLSearchParams({ status: view.status, q: view.q });
  try {
    const [orders, stats] = await Promise.all([adminApi("/api/orders?" + qs), adminApi("/api/stats")]);
    view.orders = orders; view.stats = stats;
    renderFilters(); renderAlerts(); renderList();
  } catch (err) {
    if (err.status === 401) { store("adminKey", null); showLogin(); return; }
    toast(err.message, "err");
  }
}

function renderAlerts() {
  const a = $("#alerts"); a.replaceChildren();
  const s = view.stats;
  if (s.overdue) a.append(el("span", { class: "alert bad", text: s.overdue + (s.overdue === 1 ? " order is overdue" : " orders are overdue") }));
  if (s.due_soon) a.append(el("span", { class: "alert soon", text: s.due_soon + (s.due_soon === 1 ? " order is due in the next 7 days" : " orders are due in the next 7 days") }));
}

function renderFilters() {
  const f = $("#filters"); f.replaceChildren();
  const c = view.stats.counts;
  const tabs = [["all", "All", view.stats.total], ...["new", "confirmed", "cutting", "stitching", "ready", "delivered", "cancelled"].map((s) => [s, STATUS_LABEL[s], c[s]])];
  tabs.forEach(([key, label, n]) => {
    f.append(el("button", { type: "button", "aria-pressed": String(view.status === key), onclick: () => { view.status = key; load(); } }, label, el("b", { text: String(n) })));
  });
}

function renderList() {
  const box = $("#list"); box.replaceChildren();
  if (!view.orders.length) {
    const searching = view.q || view.status !== "all";
    box.append(el("div", { class: "empty-list" },
      el("h3", { text: searching ? "No orders match" : "No orders yet" }),
      el("p", { text: searching ? "Try a different search or choose All." : "Orders appear here when a customer presses “Send to the tailor”." })));
    return;
  }
  view.orders.forEach((o) => {
    const late = isLate(o);
    box.append(el("button", { type: "button", class: "orow", onclick: () => openOrder(o.id) },
      el("img", { class: "t", src: o.preview_url, alt: "", loading: "lazy" }),
      el("span", { class: "c" }, el("strong", { text: `#${o.id} ${o.customer_name}` }), el("span", { text: o.phone })),
      el("span", { class: "col" }, o.garment_label, el("small", { text: "Placed " + fmtDate(o.created_at) })),
      el("span", { class: "col" + (late ? " late" : "") }, dueOf(o) ? fmtDate(dueOf(o)) : "No date set", late ? el("small", { text: "Overdue" }) : (!o.delivery_date && o.due_date ? el("small", { text: "Customer’s date" }) : null)),
      el("span", { class: "col" }, el("span", { class: "badge " + o.status, text: STATUS_LABEL[o.status] || o.status }))));
  });
}

let timer = null;
$("#search").addEventListener("input", (e) => { clearTimeout(timer); timer = setTimeout(() => { view.q = e.target.value.trim(); load(); }, 250); });

// ------------------------------------------------------------------ order dialog
const dlg = $("#dlg");

function customerMessage(o) {
  const tail = {
    new: "has been received.", confirmed: "is confirmed.", cutting: "is being cut.", stitching: "is being stitched.",
    ready: "is ready for pickup.", delivered: "has been delivered. Thank you!", cancelled: "was cancelled.",
  }[o.status] || "has an update.";
  let t = `Hi ${o.customer_name}, this is ${CONFIG.shop.name}. Your ${o.garment_label} (order #${o.id}) ${tail}`;
  if (o.delivery_date && OPEN.includes(o.status) && o.status !== "ready") t += ` Expected by ${fmtDate(o.delivery_date)}.`;
  if (o.status === "ready" && o.balance > 0) t += ` Balance to pay: ${money(o.balance)}.`;
  return t;
}

function updateBalance() {
  const p = $("#fPrice").value, a = $("#fAdvance").value;
  $("#dBalance").textContent = p === "" ? "-" : money(Math.max(parseFloat(p) - (parseFloat(a) || 0), 0));
}
$("#fPrice").addEventListener("input", updateBalance);
$("#fAdvance").addEventListener("input", updateBalance);

function fillDialog(o) {
  view.current = o;
  $("#dTitle").textContent = `Order #${o.id}`;
  $("#dOrig").src = o.original_url; $("#dPrev").src = o.preview_url; $("#dSwatch").src = o.swatch_url;
  const sp = $("#dSpec"); sp.replaceChildren();
  o.spec_rows.forEach((r) => sp.append(el("dt", { text: r.label }), el("dd", { text: r.value })));
  if (o.extras && o.extras.length) sp.append(el("dt", { text: "For the tailor" }), el("dd", { text: o.extras.join(", ") }));
  $("#dInstr").textContent = o.instructions || "";
  $("#dName").textContent = o.customer_name;
  const ph = $("#dPhone"); ph.textContent = o.phone; ph.href = "tel:" + o.phone.replace(/[^\d+]/g, "");
  $("#dMeta").textContent = "Placed " + fmtDate(o.created_at, true) + (o.due_date ? ". Customer needs it by " + fmtDate(o.due_date) + "." : "");
  $("#dNotes").textContent = o.notes ? "Customer note: " + o.notes : "";
  const st = $("#fStatus");
  if (!st.options.length) view.statuses.forEach((s) => st.add(new Option(STATUS_LABEL[s], s)));
  st.value = o.status;
  $("#fDate").value = o.delivery_date || "";
  $("#fPrice").value = o.price ?? ""; $("#fAdvance").value = o.advance ?? "";
  $("#fNotes").value = o.tailor_notes || "";
  updateBalance();
  $("#dPrint").href = "/static/job.html?id=" + o.id;
  $("#dWa").href = waLink(o.phone, customerMessage(o));
  setMsg($("#dMsg"), "", "");
}

async function openOrder(id) {
  try { fillDialog(await adminApi("/api/orders/" + id)); dlg.showModal(); }
  catch (err) { toast(err.message, "err"); }
}

$("#dSave").addEventListener("click", async () => {
  const o = view.current; if (!o) return;
  const num = (v) => (v === "" ? null : parseFloat(v));
  const body = { status: $("#fStatus").value, delivery_date: $("#fDate").value, tailor_notes: $("#fNotes").value };
  if ($("#fPrice").value !== "") body.price = num($("#fPrice").value);
  if ($("#fAdvance").value !== "") body.advance = num($("#fAdvance").value);
  const btn = $("#dSave"); btn.disabled = true;
  try {
    const saved = await adminApi("/api/orders/" + o.id, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    fillDialog(saved);
    setMsg($("#dMsg"), "Saved.", "ok");
    load();
  } catch (err) { setMsg($("#dMsg"), err.message, "err"); }
  finally { btn.disabled = false; }
});

$("#dDelete").addEventListener("click", async () => {
  const o = view.current; if (!o) return;
  if (!confirm(`Delete order #${o.id} and erase its photos? This cannot be undone.`)) return;
  try { await adminApi("/api/orders/" + o.id, { method: "DELETE" }); dlg.close(); toast("Order deleted."); load(); }
  catch (err) { setMsg($("#dMsg"), err.message, "err"); }
});

$("#exportCsv").addEventListener("click", async () => {
  const qs = new URLSearchParams({ status: view.status, q: view.q });
  try {
    const res = await fetch("/api/orders.csv?" + qs, { headers: adminKey() ? { "X-Admin-Key": adminKey() } : {} });
    if (!res.ok) throw new Error("Could not export the orders.");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(await res.blob());
    a.download = "orders-" + todayIso() + ".csv";
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  } catch (err) { toast(err.message, "err"); }
});

$("#dClose").addEventListener("click", () => dlg.close());
dlg.addEventListener("click", (e) => { if (e.target === dlg) dlg.close(); });

// ------------------------------------------------------------------ start
async function start() {
  $("#board").hidden = false;
  $("#logout").hidden = !CONFIG.admin_required;
  $$("[data-icon]").forEach((n) => { n.innerHTML = ICON[n.dataset.icon] || ""; n.style.display = "inline-flex"; });
  load();
}

(async function init() {
  await loadConfig("Staff dashboard");
  view.statuses = ["new", "confirmed", "cutting", "stitching", "ready", "delivered", "cancelled"];
  if (!CONFIG.admin_required) return start();
  try { await adminApi("/api/admin/check"); start(); }
  catch (e) { showLogin(); }
})();
