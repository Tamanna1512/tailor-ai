"use strict";
/* Helpers shared by every page. */

const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => Array.from(root.querySelectorAll(s));

const STATUS_LABEL = {
  new: "Order received", confirmed: "Confirmed", cutting: "Cutting", stitching: "Stitching",
  ready: "Ready for pickup", delivered: "Delivered", cancelled: "Cancelled",
};

let CONFIG = null;

function store(key, value) {
  try {
    if (value === undefined) return sessionStorage.getItem(key);
    if (value === null) sessionStorage.removeItem(key); else sessionStorage.setItem(key, value);
  } catch (e) { /* storage can be blocked */ }
  return null;
}
function keep(key, value) {
  try {
    if (value === undefined) return localStorage.getItem(key);
    if (value === null) localStorage.removeItem(key); else localStorage.setItem(key, value);
  } catch (e) { /* storage can be blocked */ }
  return null;
}

function toast(msg, kind) {
  const old = $(".toast"); if (old) old.remove();
  const t = document.createElement("div");
  t.className = "toast" + (kind === "err" ? " err" : "");
  t.setAttribute("role", "status");
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 4200);
}

function setMsg(el, text, kind) {
  el.textContent = text || "";
  el.className = "msg" + (kind ? " " + kind : "");
}

function el(tag, props, ...kids) {
  const e = document.createElement(tag);
  if (props) for (const [k, v] of Object.entries(props)) {
    if (k === "class") e.className = v;
    else if (k === "text") e.textContent = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) e.setAttribute(k, v === true ? "" : v);
  }
  kids.flat().forEach((k) => { if (k != null && k !== false) e.append(k.nodeType ? k : document.createTextNode(k)); });
  return e;
}

function money(n) {
  if (n === null || n === undefined || n === "") return "";
  const cur = (CONFIG && CONFIG.shop.currency) || "₹";
  return cur + Number(n).toLocaleString("en-IN", { maximumFractionDigits: 2 });
}

function fmtDate(s, withTime) {
  if (!s) return "";
  const d = new Date(String(s).replace(" ", "T"));
  if (isNaN(d)) return s;
  return withTime
    ? d.toLocaleString("en-IN", { day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit" })
    : d.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

function waLink(phone, text) {
  let d = String(phone || "").replace(/\D/g, "");
  const cc = (CONFIG && CONFIG.shop.country_code) || "91";
  if (d.length === 10) d = cc + d;
  return "https://wa.me/" + d + "?text=" + encodeURIComponent(text);
}

/* Fills the shop name, logo, phone and address on every page from /api/config. */
async function loadConfig(pageTitle) {
  try {
    CONFIG = await (await fetch("/api/config")).json();
  } catch (e) {
    CONFIG = { shop: { name: "StitchView", tagline: "", phone: "", whatsapp: "", address: "", logo: "", country_code: "91", currency: "₹" }, admin_required: false };
  }
  const s = CONFIG.shop;
  $$("[data-shop-name]").forEach((n) => { n.textContent = s.name; });
  $$("[data-shop-tagline]").forEach((n) => { n.textContent = s.tagline; });
  $$("[data-shop-address]").forEach((n) => { n.textContent = s.address; n.hidden = !s.address; });
  $$("[data-shop-phone]").forEach((a) => {
    if (s.phone) { a.href = "tel:" + s.phone.replace(/[^\d+]/g, ""); a.textContent = s.phone; a.hidden = false; }
    else a.hidden = true;
  });
  if (s.logo) {
    $$(".brand .mark").forEach((m) => {
      const img = el("img", { class: "logo", src: s.logo, alt: "" });
      m.replaceWith(img);
    });
  }
  document.title = (pageTitle ? pageTitle + " | " : "") + s.name;
  return CONFIG;
}

/* Staff API calls: sends the admin key; asks for it again when the server says 401. */
function adminKey() { return store("adminKey") || ""; }
async function adminApi(path, opts = {}) {
  opts.headers = Object.assign({}, opts.headers || {}, adminKey() ? { "X-Admin-Key": adminKey() } : {});
  const res = await fetch(path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(typeof data.detail === "string" ? data.detail : "Something went wrong. Please try again.");
    err.status = res.status;
    throw err;
  }
  return data;
}

const ICON = {
  mark: '<svg class="mark" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 3c-1.8 0-3 1.2-3 2.8v14.6"/><ellipse cx="18" cy="5.6" rx="1.2" ry="2.2" fill="currentColor" stroke="none"/><path d="M18 20.4c0 4.2-3.6 6.6-7.5 6.6S3 24.8 3 21.5 6 17 9.5 17c3 0 5 1.6 5 4" stroke-dasharray="1 4"/><path d="M26 27H14"/></svg>',
  camera: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 8a2 2 0 0 1 2-2h2l1.5-2h7L17 6h2a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><circle cx="12" cy="13" r="3.5"/></svg>',
  download: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 4v11m0 0-4-4m4 4 4-4M5 20h14"/></svg>',
  share: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="m8.2 10.8 7.6-3.6M8.2 13.2l7.6 3.6"/></svg>',
  crop: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 3v13a2 2 0 0 0 2 2h13M3 6h13a2 2 0 0 1 2 2v13"/></svg>',
  mic: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>',
  print: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 9V3h10v6M7 17H5a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2"/><rect x="7" y="14" width="10" height="7"/></svg>',
  chat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a8 8 0 0 1-11.7 7L3 21l2-5.6A8 8 0 1 1 21 12z"/></svg>',
};

/* Simple line icons for the catalog (48x48). */
const GARMENT_ICON = {
  kurta: "M16 8l4-2q4 4 8 0l4 2 8 10-4 4-3-3 1 24H14l1-24-3 3-4-4z",
  blouse: "M16 10l4-2q4 4 8 0l4 2 8 6-3 5-4-2v11H15V19l-4 2-3-5z",
  shirt: "M15 9l5-3 4 5 4-5 5 3 8 9-4 4-3-3 1 24H14l1-24-3 3-4-4zM24 11v28",
  dress: "M17 6h3q4 4 8 0h3l-1 12 10 24H8l10-24z",
  salwar: "M15 6h18l2 36h-8l-3-22-3 22h-8z",
  lehenga: "M18 8h12l12 34H6zM18 12h12",
};
function garmentSvg(id) {
  return '<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" aria-hidden="true"><path d="' + (GARMENT_ICON[id] || GARMENT_ICON.kurta) + '"/></svg>';
}
