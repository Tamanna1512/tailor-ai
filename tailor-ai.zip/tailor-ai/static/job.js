"use strict";

$("#printBtn").onclick = () => window.print();

(async function init() {
  await loadConfig("Job card");
  const id = parseInt(new URLSearchParams(location.search).get("id"), 10);
  if (!id) { setMsg($("#msg"), "No order selected. Open a job card from the dashboard.", "err"); return; }
  try {
    const o = await adminApi("/api/orders/" + id);
    document.title = `Job card #${o.id} | ${CONFIG.shop.name}`;
    $("#jId").textContent = "#" + o.id;
    $("#jName").textContent = o.customer_name;
    $("#jPhone").textContent = o.phone;
    $("#jDate").textContent = fmtDate(o.created_at);
    $("#jDue").textContent = o.delivery_date ? fmtDate(o.delivery_date) : o.due_date ? "Customer needs it by " + fmtDate(o.due_date) : "Not set";
    $("#jPrice").textContent = o.price != null ? money(o.price) : "Not set";
    $("#jAdv").textContent = o.advance != null ? money(o.advance) : "-";
    $("#jBal").textContent = o.balance != null ? money(o.balance) : "-";
    const sp = $("#jSpec");
    o.spec_rows.forEach((r) => sp.append(el("dt", { text: r.label }), el("dd", { text: r.value })));
    if (o.extras && o.extras.length) sp.append(el("dt", { text: "Extras" }), el("dd", { text: o.extras.join(", ") }));
    $("#jSwatch").src = o.swatch_url;
    $("#jOrig").src = o.original_url; $("#jPrev").src = o.preview_url;
    $("#jInstr").textContent = o.instructions || "";
    const notes = [o.notes && "Customer note: " + o.notes, o.tailor_notes && "Workshop note: " + o.tailor_notes].filter(Boolean);
    $("#jNotes").textContent = notes.join("   ");
    $("#sheet").hidden = false;
  } catch (err) {
    if (err.status === 401) {
      setMsg($("#msg"), "Sign in on the staff dashboard first, then open the job card again.", "err");
    } else setMsg($("#msg"), err.message, "err");
  }
})();
