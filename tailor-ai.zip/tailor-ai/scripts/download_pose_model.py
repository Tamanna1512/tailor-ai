"""Download the MediaPipe pose model once, for computers or servers where the app cannot fetch it itself.

    python scripts/download_pose_model.py                 -> saves to data/models/
    python scripts/download_pose_model.py /some/folder    -> saves into that folder

If you save it somewhere else, set TAILOR_POSE_MODEL=/some/folder/pose_landmarker_full.task in .env
"""
import sys
import urllib.request
from pathlib import Path

URL = ("https://storage.googleapis.com/mediapipe-models/pose_landmarker/"
       "pose_landmarker_full/float16/latest/pose_landmarker_full.task")

dest = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent / "data" / "models"
dest.mkdir(parents=True, exist_ok=True)
target = dest / "pose_landmarker_full.task"
if target.exists():
    print("Already there:", target)
    sys.exit(0)
print("Downloading", URL)
tmp = target.with_suffix(".part")
with urllib.request.urlopen(URL, timeout=120) as r, open(tmp, "wb") as f:
    f.write(r.read())
tmp.replace(target)
print("Saved", target, f"({target.stat().st_size // 1024} KB)")
