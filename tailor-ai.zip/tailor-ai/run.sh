#!/usr/bin/env bash
# Starts StitchView on http://localhost:8000
set -e
cd "$(dirname "$0")"
if [ ! -d venv ]; then
  python3 -m venv venv
  . venv/bin/activate
  pip install -r requirements.txt
else
  . venv/bin/activate
fi
exec uvicorn app.main:app --host 0.0.0.0 --port 8000
