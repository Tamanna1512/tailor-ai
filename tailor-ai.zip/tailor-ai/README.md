# StitchView - AI tailoring preview for your shop

Customers photograph themselves with their cloth, choose a style (or describe their own), and see how it
will look **after stitching**. They send the order to your shop, you manage it on a staff dashboard, print a
job card for the workshop, and customers follow progress on a tracking page.

## Pages

| Address | For | What it does |
|---|---|---|
| `/` | Customers | Design studio: photo, cloth, style, before/after preview, download or share the design card, send the order |
| `/track` | Customers | Order number + phone number -> progress, delivery date, balance, call / WhatsApp the shop |
| `/staff` | Your team | Sign in with the admin key. Search, filter by status, change status, set price/advance/delivery date, add workshop notes, print job card, export to spreadsheet, delete order and photos |
| `/static/job.html?id=12` | Workshop | Printable A4 job card (opens from the dashboard) |
| `/docs` | Developers | API documentation (switch off with `TAILOR_DOCS=0`) |

## Set up your shop (2 minutes)

1. Copy `.env.example` to `.env`.
2. Fill in `SHOP_NAME`, `SHOP_PHONE`, `SHOP_ADDRESS` (and `SHOP_WHATSAPP` if different from the phone).
   Optional logo: put `logo.png` in the `static` folder and set `SHOP_LOGO=/static/logo.png`.
3. Set `TAILOR_ADMIN_KEY` to a long password. Without it, anyone who knows `/staff` can open your orders.
4. Restart the app.

## Run on your computer

Python 3.10 or newer.

```bash
python -m venv venv
venv\Scripts\activate            # Windows      (Mac/Linux: source venv/bin/activate)
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Open http://localhost:8000. From a phone on the same Wi-Fi use `http://<computer-ip>:8000`.
`run.bat` (Windows) and `run.sh` (Mac/Linux) do the same.

## Put it online for customers

Customers need a public address with HTTPS (browsers only allow the camera and microphone on HTTPS).

* **Docker (any VPS):** `cp .env.example .env`, edit it, then `docker compose up -d --build`.
  Orders and photos are kept in a Docker volume. Put Caddy or nginx in front for HTTPS and set
  `TAILOR_TRUST_PROXY=1` so rate limits use each customer's real address.
* **Without Docker:** run `uvicorn` as a service behind Caddy/nginx in the same way.
* Check that the app is up with `/healthz`.

The Dockerfile was written for this project but has not been test-built on the machine that produced it. Build it
once and open `/healthz` before relying on it.

## Body-detection model

* Older MediaPipe (0.10.x): bundled, nothing to do.
* Newer MediaPipe (1.x): needs `pose_landmarker_full.task` (about 9 MB). The app downloads it on the first
  photo. On a computer with no internet, run `python scripts/download_pose_model.py` once on a connected machine
  and copy the file to `data/models/`, or set `TAILOR_POSE_MODEL` to its location.
* If the model is missing, customers still get a preview using a standard standing position, with a plain
  notice that the fit is approximate. The technical reason is written to the server log.

## Privacy and security built in

* Customers must tick a consent box before photos are kept. Photos of previews that are never sent are deleted
  after 24 hours (`TAILOR_PREVIEW_TTL_HOURS`).
* Deleting an order in the dashboard also deletes its photos.
* Staff pages and APIs need the admin key. Customers can track only with the order number **and** the phone
  number used for the order.
* The orders database and models are not downloadable. Rate limits protect the preview, order, tracking and
  sign-in endpoints. Standard security headers are sent on every response.
* Spreadsheet export neutralises text that Excel could run as a formula.
* Back up the `data` folder regularly (it holds `orders.db` and the photos).

## Settings (.env)

See `.env.example`. Main ones: `SHOP_NAME`, `SHOP_TAGLINE`, `SHOP_PHONE`, `SHOP_WHATSAPP`, `SHOP_ADDRESS`,
`SHOP_LOGO`, `SHOP_COUNTRY_CODE`, `SHOP_CURRENCY`, `TAILOR_ADMIN_KEY`, `TAILOR_TRUST_PROXY`,
`ANTHROPIC_API_KEY` (understands Hindi/Marathi descriptions), `TAILOR_DATA_DIR`.

## Project layout

```
app/        main.py (routes, security)  pose.py  fabric.py  garments.py (catalog + renderer)
            spec_parser.py (description -> style)  measurements.py  db.py (SQLite, auto-upgrades old databases)
static/     index.html track.html orders.html job.html + app.js common.js ... style.css fonts/
scripts/    download_pose_model.py
tests/      pytest suite: pip install -r requirements-dev.txt && pytest
data/       created on first run: orders.db, photos, models
```

## Honest limits

* The preview is a 2D illustration built from the body pose, not a physical cloth simulation. Real drape
  differs, and the pages say so.
* Measurements from one photo are rough. The tailor must measure with a tape.
* Garment shapes are generic templates. Unusual poses (arms crossed, sitting) fit poorly.
* For photo-realistic previews, add an image-generation model behind `garments.render()` and keep this
  renderer as the fast, free, predictable option.
